package com.infinite.ehrSystem.auth.service;

import com.infinite.ehrSystem.auth.entity.User;
import com.infinite.ehrSystem.auth.entity.UserStatus;
import com.infinite.ehrSystem.auth.repository.UserRepository;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;

    public CustomUserDetailsService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String login)
            throws UsernameNotFoundException {

        String loginValue = login.trim();

        User user = userRepository.findByUsername(loginValue)
                .or(() -> userRepository.findByEmail(loginValue))
                .filter(existingUser -> existingUser.getStatus() == UserStatus.ACTIVE)
                .orElseThrow(() -> new UsernameNotFoundException(
                        "Invalid username/email or account is locked"
                ));

        String roleName = user.getRole().getName().trim().toUpperCase();

        return org.springframework.security.core.userdetails.User
                .withUsername(user.getUsername())
                .password(user.getPassword())
                .authorities(new SimpleGrantedAuthority("ROLE_" + roleName))
                .accountLocked(user.getStatus() == UserStatus.LOCKED)
                .build();
    }
}
