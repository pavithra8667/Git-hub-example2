package com.infinite.ehrSystem.visit.service;

import com.infinite.ehrSystem.exception.VisitAlreadyClosedException;
import com.infinite.ehrSystem.exception.VisitNotFoundException;
import com.infinite.ehrSystem.auth.repository.UserRepository;
import com.infinite.ehrSystem.patient.repository.PatientRepository;
import com.infinite.ehrSystem.visit.dto.VisitDTO;
import com.infinite.ehrSystem.visit.entity.Visit;
import com.infinite.ehrSystem.visit.entity.VisitStatus;
import com.infinite.ehrSystem.visit.repository.VisitRepository;
import com.infinite.ehrSystem.visit.mapper.VisitMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import com.infinite.ehrSystem.auth.entity.User;
import com.infinite.ehrSystem.auth.entity.UserStatus;
import com.infinite.ehrSystem.patient.entity.Patient;

@Service
@RequiredArgsConstructor
public class VisitServiceImpl implements VisitService {

    private static final Logger logger = LogManager.getLogger(VisitServiceImpl.class);

    private final VisitRepository visitRepository;
    private final PatientRepository patientRepository;
    private final UserRepository userRepository;
    private final VisitMapper visitMapper;

    @Override
    @Transactional
    public VisitDTO createVisit(VisitDTO visitDTO) {
        logger.info("Creating visit");

        Visit visit = visitMapper.toEntity(visitDTO);

        // These values are generated or controlled by the service on creation.
        visit.setId(null);
        visit.setCreatedBy(null);
        visit.setCreatedOn(null);
        visit.setUpdatedBy(null);
        visit.setUpdatedOn(null);

        visit.setVisitCode(generateVisitCode());

        visit.setPatientId(visitDTO.getPatientId());

        visit.setDoctorId(visitDTO.getDoctorId());

        visit.setVisitDate(
                visitDTO.getVisitDate() != null
                        ? visitDTO.getVisitDate()
                        : LocalDateTime.now()
        );

        // New visit should always start as OPEN
        visit.setStatus(VisitStatus.OPEN);

        Visit savedVisit = visitRepository.save(visit);

        return enrichVisitDTO(savedVisit);
    }

    @Override
    @Transactional(readOnly = true)
    public VisitDTO getVisitById(UUID id) {
        logger.debug("Loading visit");

        Visit visit = visitRepository.findById(id)
                .orElseThrow(() ->
                        new VisitNotFoundException(
                                "Visit not found with id: " + id
                        )
                );

        return enrichVisitDTO(visit);
    }

    @Override
    @Transactional(readOnly = true)
    public List<VisitDTO> getVisitsByPatient(UUID patientId) {

        return visitRepository
                .findByPatientId(patientId)
                .stream()
                .map(this::enrichVisitDTO)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<VisitDTO> getVisitsByDoctor(UUID doctorId) {

        return visitRepository
                .findByDoctorId(doctorId)
                .stream()
                .map(this::enrichVisitDTO)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<VisitDTO> getAllVisits() {

        return visitRepository.findAll()
                .stream()
                .map(this::enrichVisitDTO)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Patient> getPatientsForVisitForm() {
        return patientRepository.findAll()
                .stream()
                .sorted(Comparator.comparing(Patient::getName, String.CASE_INSENSITIVE_ORDER))
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<User> getActiveDoctorsForVisitForm() {
        return userRepository.findAll()
                .stream()
                .filter(user -> user.getStatus() == UserStatus.ACTIVE)
                .filter(user -> user.getRole() != null
                        && user.getRole().getName() != null
                        && user.getRole().getName().toLowerCase().contains("doctor"))
                .sorted(Comparator.comparing(User::getUsername, String.CASE_INSENSITIVE_ORDER))
                .toList();
    }

    @Override
    @Transactional
    public VisitDTO closeVisit(UUID id) {
        logger.info("Closing visit");

        Visit visit = visitRepository.findById(id)
                .orElseThrow(() ->
                        new VisitNotFoundException(
                                "Visit not found with id: " + id
                        )
                );

        if (visit.getStatus() == VisitStatus.CLOSED) {
            throw new VisitAlreadyClosedException(
                    "Visit is already closed"
            );
        }

        visit.setStatus(VisitStatus.CLOSED);

        Visit updatedVisit = visitRepository.save(visit);

        return enrichVisitDTO(updatedVisit);
    }

    private String generateVisitCode() {

        return "VIS-" +
                UUID.randomUUID()
                        .toString()
                        .substring(0, 8)
                        .toUpperCase();
    }

    private VisitDTO enrichVisitDTO(Visit visit) {
        Patient patient = visit.getPatientId() == null
                ? null
                : patientRepository.findById(visit.getPatientId()).orElse(null);
        User doctor = visit.getDoctorId() == null
                ? null
                : userRepository.findById(visit.getDoctorId()).orElse(null);
        return visitMapper.toDTO(visit, patient, doctor);
    }
}
