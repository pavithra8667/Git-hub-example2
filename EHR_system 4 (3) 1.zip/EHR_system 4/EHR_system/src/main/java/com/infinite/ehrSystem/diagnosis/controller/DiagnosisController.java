package com.infinite.ehrSystem.diagnosis.controller;
import com.infinite.ehrSystem.diagnosis.dto.DiagnosisDTO;
import com.infinite.ehrSystem.diagnosis.service.DiagnosisService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.UUID;
@RestController
@Log4j2
@RequiredArgsConstructor
public class DiagnosisController {
    private final DiagnosisService diagnosisService;

    @PostMapping("/api/visits/{visitId}/diagnoses")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<DiagnosisDTO> createDiagnosis(
            @PathVariable UUID visitId,
            @Valid @RequestBody DiagnosisDTO diagnosisDTO) {
        log.info("Creating diagnosis");
        DiagnosisDTO createdDiagnosis = diagnosisService.createDiagnosis(visitId, diagnosisDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdDiagnosis);
    }

    @GetMapping("/api/visits/{visitId}/diagnoses")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','PATIENT')")
    public ResponseEntity<List<DiagnosisDTO>> getDiagnosesByVisit(@PathVariable UUID visitId)
    {
        log.debug("Fetching diagnoses by visit");
        return ResponseEntity.ok(diagnosisService.getDiagnosesByVisit(visitId));
    }

    @GetMapping("/api/diagnoses/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','PATIENT')")
    public ResponseEntity<DiagnosisDTO> getDiagnosisById(@PathVariable UUID id) {
        log.debug("Fetching diagnosis");
        return ResponseEntity.ok(diagnosisService.getDiagnosisById(id));
    }

    @DeleteMapping("/api/diagnoses/{id}")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<Void> deleteDiagnosis(@PathVariable UUID id) {
        log.info("Deleting diagnosis");
        diagnosisService.deleteDiagnosis(id);
        return ResponseEntity.noContent().build();
    }
}
