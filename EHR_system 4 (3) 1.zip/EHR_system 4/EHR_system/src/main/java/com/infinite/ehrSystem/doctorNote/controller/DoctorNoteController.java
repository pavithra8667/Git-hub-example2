package com.infinite.ehrSystem.doctorNote.controller;

import com.infinite.ehrSystem.doctorNote.dto.DoctorNoteDTO;
import com.infinite.ehrSystem.doctorNote.service.DoctorNoteService;
import com.infinite.ehrSystem.patient.entity.Patient;
import com.infinite.ehrSystem.patient.repository.PatientRepository;
import com.infinite.ehrSystem.visit.service.VisitService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.UUID;
import java.util.HashMap;
import java.util.Map;

@Controller
public class DoctorNoteController {
    private static final Logger logger = LoggerFactory.getLogger(DoctorNoteController.class);

    @Autowired
    private DoctorNoteService doctorNoteService;
    @Autowired
    private VisitService visitService;
    @Autowired
    private PatientRepository patientRepository;

    @GetMapping("/doctor-notes/view")
    public String doctorNotesView(@RequestParam UUID visitId, @RequestParam(required = false) UUID doctorId, Model model) {
        Map<String, Object> viewDetails = doctorNoteService.getVisitDetailsForView(visitId, doctorId);
        logger.info("doctorNotesView called for visitId={} doctorId={}", visitId, doctorId);

        model.addAttribute("visitId", viewDetails.get("visitId"));
        model.addAttribute("patientId", viewDetails.get("patientId"));
        model.addAttribute("patientName", viewDetails.get("patientName"));
        model.addAttribute("doctorId", viewDetails.get("doctorId"));
        model.addAttribute("doctorName", viewDetails.get("doctorName"));
        model.addAttribute("visitStatus", viewDetails.get("visitStatus"));
        model.addAttribute("doctorNotes", viewDetails.get("notes"));

        return "doctor-notes-view";
    }

    @GetMapping("/patient-doctor-notes")
    public String patientDoctorNotes(@RequestParam UUID patientId, Model model) {
        Patient patient = patientRepository.findById(patientId).orElse(null);
        if (patient != null) {
            model.addAttribute("patientName", patient.getName());
            model.addAttribute("patientCode", patient.getPatientCode());
        }

        model.addAttribute("patientId", patientId);
        model.addAttribute("doctorNotes", doctorNoteService.getNotesByPatientId(patientId));
        return "patient-doctor-notes";
    }

    @GetMapping("/doctor-notes/form")
    public String doctorNotesForm(@RequestParam UUID visitId, @RequestParam UUID doctorId, Model model) {
        Map<String, Object> formDetails = doctorNoteService.getVisitDetailsForForm(visitId, doctorId);
        logger.info("doctorNotesForm called for visitId={} doctorId={}", visitId, doctorId);
        
        model.addAttribute("visitId", formDetails.get("visitId"));
        model.addAttribute("doctorId", formDetails.get("doctorId"));
        model.addAttribute("patientName", formDetails.get("patientName"));
        model.addAttribute("doctorName", formDetails.get("doctorName"));

        return "doctor-notes-form";
    }


    @PostMapping(value = "/doctor-notes/save", produces = "application/json")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> saveDoctorNote(@Valid @RequestBody DoctorNoteDTO doctorNoteDTO) {
        logger.info("saveDoctorNote called for visitId={} doctorId={}", doctorNoteDTO.getVisitId(), doctorNoteDTO.getDoctorId());
        try {
            doctorNoteService.saveDoctorNote(doctorNoteDTO);

            Map<String, Object> resp = new HashMap<>();
            resp.put("success", true);
            resp.put("message", "Doctor note saved successfully");
            resp.put("redirect", "/doctor-notes/view?visitId=" + doctorNoteDTO.getVisitId() + "&doctorId=" + doctorNoteDTO.getDoctorId());
            return ResponseEntity.ok(resp);
        } catch (IllegalArgumentException | EntityNotFoundException ex) {
            logger.error("Validation error while saving doctor note: {}", ex.getMessage());
            Map<String, Object> resp = new HashMap<>();
            resp.put("success", false);
            resp.put("message", ex.getMessage());
            return ResponseEntity.badRequest().body(resp);
        } catch (Exception ex) {
            logger.error("Unexpected error while saving doctor note", ex);
            Map<String, Object> resp = new HashMap<>();
            resp.put("success", false);
            resp.put("message", "Internal server error");
            return ResponseEntity.status(500).body(resp);
        }
    }
}