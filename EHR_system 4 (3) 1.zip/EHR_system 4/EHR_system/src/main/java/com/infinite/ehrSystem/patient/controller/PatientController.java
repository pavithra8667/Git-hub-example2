package com.infinite.ehrSystem.patient.controller;

import com.infinite.ehrSystem.patient.dto.PatientDto;
import com.infinite.ehrSystem.patient.service.PatientService;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.access.prepost.PreAuthorize;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.*;

import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.UUID;


@Controller
public class PatientController {

    private final PatientService patientService;


    public PatientController(PatientService patientService) {
        this.patientService = patientService;
    }


    // =====================================================
    // REST API
    // =====================================================


    @GetMapping("/api/patients")
    @ResponseBody
    @PreAuthorize("hasAnyRole('ADMIN', 'DOCTOR', 'LAB_TECH')")
    public ResponseEntity<List<PatientDto>> getPatients(
            @RequestParam(required = false) String search) {

        return ResponseEntity.ok(
                patientService.searchPatients(search)
        );
    }


    @PostMapping("/api/patients/register")
    @ResponseBody
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<PatientDto> registerPatientApi(
            @Valid @RequestBody PatientDto patientDto) {

        PatientDto createdPatient =
                patientService.registerPatient(patientDto);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(createdPatient);
    }


    @GetMapping("/api/patients/{id}")
    @ResponseBody
    @PreAuthorize("hasAnyRole('ADMIN', 'DOCTOR', 'LAB_TECH', 'PATIENT')")
    public ResponseEntity<PatientDto> getPatientApi(
            @PathVariable UUID id) {

        return ResponseEntity.ok(
                patientService.getPatient(id)
        );
    }


    @PutMapping("/api/patients/{id}")
    @ResponseBody
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<PatientDto> updatePatientApi(
            @PathVariable UUID id,
            @Valid @RequestBody PatientDto patientDto) {

        return ResponseEntity.ok(
                patientService.updatePatient(id, patientDto)
        );
    }


    // =====================================================
    // JSP - PATIENT LIST
    // =====================================================


    @GetMapping("/patients")
    @PreAuthorize("hasAnyRole('ADMIN', 'DOCTOR', 'LAB_TECH')")
    public String patientList(
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = "patients") String module,
            Model model) {

        model.addAttribute(
                "patients",
                patientService.searchPatients(search)
        );

        model.addAttribute(
                "search",
                search
        );

        model.addAttribute(
                "module",
                module
        );

        return "patient-list";
    }


    // =====================================================
    // JSP - OPEN REGISTER FORM
    // =====================================================


    @GetMapping("/patients/new")
    @PreAuthorize("hasRole('ADMIN')")
    public String showPatientForm(Model model) {

        model.addAttribute(
                "patient",
                new PatientDto()
        );

        return "patient-form";
    }


    // =====================================================
    // JSP - REGISTER PATIENT
    // =====================================================


    @PostMapping("/patients")
    @PreAuthorize("hasRole('ADMIN')")
    public String registerPatient(
            @Valid @ModelAttribute("patient") PatientDto patientDto,
            BindingResult bindingResult,
            Model model,
            RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            return "patient-form";
        }

        try {

            PatientDto savedPatient =
                    patientService.registerPatient(patientDto);

            redirectAttributes.addFlashAttribute(
                    "successMessage",
                    "Patient registered successfully. Patient Code: "
                            + savedPatient.getPatientCode()
            );

            return "redirect:/patients";

        } catch (RuntimeException exception) {

            model.addAttribute(
                    "errorMessage",
                    exception.getMessage()
            );

            return "patient-form";
        }
    }


    // =====================================================
    // JSP - VIEW PATIENT
    // =====================================================


    @GetMapping("/patients/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'DOCTOR', 'LAB_TECH', 'PATIENT')")
    public String patientView(
            @PathVariable UUID id,
            Model model) {

        model.addAttribute(
                "patient",
                patientService.getPatient(id)
        );

        return "patient-view";
    }


    // =====================================================
    // JSP - OPEN EDIT FORM
    // =====================================================


    @GetMapping("/patients/{id}/edit")
    @PreAuthorize("hasRole('ADMIN')")
    public String showEditPatient(
            @PathVariable UUID id,
            Model model) {

        model.addAttribute(
                "patient",
                patientService.getPatient(id)
        );

        return "patient-form";
    }


    // =====================================================
    // JSP - UPDATE PATIENT
    // =====================================================


    @PostMapping("/patients/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String updatePatient(
            @PathVariable UUID id,
            @Valid @ModelAttribute("patient") PatientDto patientDto,
            BindingResult bindingResult,
            Model model,
            RedirectAttributes redirectAttributes) {

        patientDto.setId(id);

        if (bindingResult.hasErrors()) {
            return "patient-form";
        }

        try {

            patientService.updatePatient(
                    id,
                    patientDto
            );

            redirectAttributes.addFlashAttribute(
                    "successMessage",
                    "Patient updated successfully"
            );

            return "redirect:/patients/" + id;

        } catch (RuntimeException exception) {

            model.addAttribute(
                    "errorMessage",
                    exception.getMessage()
            );

            return "patient-form";
        }
    }
}