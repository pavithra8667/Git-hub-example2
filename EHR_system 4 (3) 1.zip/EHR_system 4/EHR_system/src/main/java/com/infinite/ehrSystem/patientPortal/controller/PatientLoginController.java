package com.infinite.ehrSystem.patientPortal.controller;

import com.infinite.ehrSystem.auth.entity.User;
import com.infinite.ehrSystem.auth.repository.UserRepository;
import com.infinite.ehrSystem.patient.entity.Patient;
import com.infinite.ehrSystem.patient.repository.PatientRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
public class PatientLoginController {

    private final PatientRepository patientRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public PatientLoginController(PatientRepository patientRepository,
                                 UserRepository userRepository,
                                 PasswordEncoder passwordEncoder) {
        this.patientRepository = patientRepository;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/patient-login")
    public String showPatientLogin(
            @RequestParam(required = false) String error,
            @RequestParam(required = false) String logout,
            Model model) {

        if (error != null) {
            model.addAttribute("errorMessage", "Invalid patient username or password.");
        }

        if (logout != null) {
            model.addAttribute("successMessage", "You have been logged out successfully.");
        }

        return "patient-login";
    }

    @PostMapping("/patient-login")
    public String loginPatient(
            @RequestParam String username,
            @RequestParam String password,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        String cleanUsername = username == null ? "" : username.trim();
        String cleanPassword = password == null ? "" : password;

        if (cleanUsername.isBlank() || cleanPassword.isBlank()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Username and password are required.");
            return "redirect:/patient-login?error=true";
        }

        Optional<User> userOpt = userRepository.findByUsername(cleanUsername);
        if (userOpt.isEmpty()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid patient username or password.");
            return "redirect:/patient-login?error=true";
        }

        User user = userOpt.get();
        if (!passwordEncoder.matches(cleanPassword, user.getPassword())) {
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid patient username or password.");
            return "redirect:/patient-login?error=true";
        }

        if (!user.isPasswordChanged()) {
            session.setAttribute("pendingPatientUsername", user.getUsername());
            return "redirect:/patient/change-password";
        }
 
        Optional<Patient> patientOpt = patientRepository.findByPortalUser_Id(user.getId());
        if (patientOpt.isEmpty()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Patient portal account not linked.");
            return "redirect:/patient-login?error=true";
        }
 
        Patient patient = patientOpt.get();

        // Establish a Spring Security Authentication for the patient session so @PreAuthorize checks work
        UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(
                user.getUsername(),
                null,
                java.util.List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole().getName().toUpperCase()))
        );
        SecurityContextHolder.getContext().setAuthentication(auth);

        session.setAttribute("patientId", patient.getId());
        session.setAttribute("patientName", patient.getName());
        session.setAttribute("patientCode", patient.getPatientCode());
 
        return "redirect:/patient-portal?patientId=" + patient.getId();
    }

    @GetMapping("/patient-logout")
    public String logoutPatient(HttpSession session) {
        session.invalidate();
        return "redirect:/patient-login?logout=true";
    }
}
