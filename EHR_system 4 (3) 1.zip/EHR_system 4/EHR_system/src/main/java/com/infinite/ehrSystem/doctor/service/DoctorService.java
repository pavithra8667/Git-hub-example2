package com.infinite.ehrSystem.doctor.service;

import com.infinite.ehrSystem.doctor.dto.DoctorDTO;

import java.util.List;
import java.util.UUID;

public interface DoctorService {

    DoctorDTO createDoctor(DoctorDTO doctorDTO);

    DoctorDTO getDoctorById(UUID id);

    DoctorDTO getDoctorByUserId(UUID userId);

    List<DoctorDTO> getAllDoctors();

    List<DoctorDTO> getDoctorsBySpecialization(String specialization);

    List<DoctorDTO> getAvailableDoctors();

    DoctorDTO updateDoctor(UUID id, DoctorDTO doctorDTO);

    void deleteDoctor(UUID id);
}
