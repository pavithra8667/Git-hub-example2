package com.infinite.ehrSystem.visit.mapper;

import com.infinite.ehrSystem.auth.entity.User;
import com.infinite.ehrSystem.patient.entity.Patient;
import com.infinite.ehrSystem.visit.dto.VisitDTO;
import com.infinite.ehrSystem.visit.entity.Visit;
import org.springframework.stereotype.Component;

@Component
public class VisitMapper {

    public VisitDTO toDTO(Visit visit) {
        return toDTO(visit, null, null);
    }

    public VisitDTO toDTO(Visit visit, Patient patient, User doctor) {
        if (visit == null) {
            return null;
        }

        return VisitDTO.builder()
                .id(visit.getId())
                .visitCode(visit.getVisitCode())
                .patientId(visit.getPatientId())
                .doctorId(visit.getDoctorId())
                .doctorName(doctor == null ? null : doctor.getUsername())
                .visitDate(visit.getVisitDate())
                .status(visit.getStatus())
                .patientName(patient == null ? null : patient.getName())
                .patientCode(patient == null ? null : patient.getPatientCode())
                .createdBy(visit.getCreatedBy())
                .createdOn(visit.getCreatedOn())
                .updatedBy(visit.getUpdatedBy())
                .updatedOn(visit.getUpdatedOn())
                .build();
    }

    public Visit toEntity(VisitDTO dto) {
        if (dto == null) {
            return null;
        }

        Visit visit = new Visit();
        visit.setId(dto.getId());
        visit.setVisitCode(dto.getVisitCode());
        visit.setPatientId(dto.getPatientId());
        visit.setDoctorId(dto.getDoctorId());
        visit.setVisitDate(dto.getVisitDate());
        visit.setStatus(dto.getStatus());
        visit.setCreatedBy(dto.getCreatedBy());
        visit.setCreatedOn(dto.getCreatedOn());
        visit.setUpdatedBy(dto.getUpdatedBy());
        visit.setUpdatedOn(dto.getUpdatedOn());
        return visit;
    }
}
