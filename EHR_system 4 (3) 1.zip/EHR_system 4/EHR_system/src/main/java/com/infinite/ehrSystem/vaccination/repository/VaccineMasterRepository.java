package com.infinite.ehrSystem.vaccination.repository;

import com.infinite.ehrSystem.vaccination.entity.VaccineMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface VaccineMasterRepository extends JpaRepository<VaccineMaster, UUID> {

    Optional<VaccineMaster> findByVaccineNameIgnoreCase(
            String vaccineName);
}