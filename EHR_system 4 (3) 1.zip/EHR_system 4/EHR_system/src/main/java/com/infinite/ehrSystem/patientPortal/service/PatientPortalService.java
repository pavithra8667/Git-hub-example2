package com.infinite.ehrSystem.patientPortal.service;

import com.infinite.ehrSystem.patientPortal.dto.PatientPortalDTO;

import java.util.UUID;

public interface PatientPortalService {

    PatientPortalDTO getPatientPortal(String username);

    // allow resolving portal by patientId (useful for staff or unauthenticated requests)
    PatientPortalDTO getPatientPortalByPatientId(UUID patientId);
}