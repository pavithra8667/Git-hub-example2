package com.infinite.ehrSystem.patientPortal.controller;

import com.infinite.ehrSystem.auth.entity.User;
import com.infinite.ehrSystem.auth.repository.UserRepository;
import com.infinite.ehrSystem.patient.entity.Patient;
import com.infinite.ehrSystem.patient.repository.PatientRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
public class PatientPasswordController {

    private final UserRepository userRepository;
    private final PatientRepository patientRepository;
    private final PasswordEncoder passwordEncoder;

    public PatientPasswordController(UserRepository userRepository,
                                    PatientRepository patientRepository,
                                    PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.patientRepository = patientRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/patient/change-password")
    public String showChangePassword(HttpSession session, Model model) {
        String username = (String) session.getAttribute("pendingPatientUsername");
        if (username == null) {
            return "redirect:/patient-login";
        }

        model.addAttribute("username", username);
        return "patient-change-password";
    }

    @PostMapping("/patient/change-password")
    public String changePassword(@RequestParam String username,
                                @RequestParam String currentPassword,
                                @RequestParam String newPassword,
                                @RequestParam String confirmPassword,
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {

        Optional<User> userOpt = userRepository.findByUsername(username.trim());
        if (userOpt.isEmpty()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid patient session.");
            return "redirect:/patient-login?error=true";
        }

        User user = userOpt.get();
        if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
            redirectAttributes.addFlashAttribute("errorMessage", "Current password is incorrect.");
            return "redirect:/patient/change-password";
        }

        if (!newPassword.equals(confirmPassword)) {
            redirectAttributes.addFlashAttribute("errorMessage", "New password and confirm password do not match.");
            return "redirect:/patient/change-password";
        }

        if (newPassword == null || newPassword.trim().isBlank() || newPassword.length() < 6) {
            redirectAttributes.addFlashAttribute("errorMessage", "New password must be at least 6 characters.");
            return "redirect:/patient/change-password";
        }

        if (passwordEncoder.matches(newPassword, user.getPassword())) {
            redirectAttributes.addFlashAttribute("errorMessage", "New password must be different from the current password.");
            return "redirect:/patient/change-password";
        }

        user.setPassword(passwordEncoder.encode(newPassword));
        user.setPasswordChanged(true);
        userRepository.save(user);

        Optional<Patient> patientOpt = patientRepository.findByPortalUser_Id(user.getId());
        if (patientOpt.isPresent()) {
            Patient patient = patientOpt.get();
            session.setAttribute("patientId", patient.getId());
            session.setAttribute("patientName", patient.getName());
            session.setAttribute("patientCode", patient.getPatientCode());
        }

        session.removeAttribute("pendingPatientUsername");
        redirectAttributes.addFlashAttribute("successMessage", "Password changed successfully.");
        return "redirect:/patient-portal?patientId=" + patientOpt.map(Patient::getId).orElse(null);
    }
}
