package com.infinite.ehrSystem.labResults.controller;

import com.infinite.ehrSystem.labResults.dto.LabOrderDTO;
import com.infinite.ehrSystem.labResults.entity.LabOrderStatus;
import com.infinite.ehrSystem.labResults.service.LabOrderService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import lombok.extern.log4j.Log4j2;

import java.util.List;
import java.util.UUID;

@RestController
@Log4j2
@RequestMapping("/api/lab-orders")
public class LabOrderController {

    private final LabOrderService labOrderService;

    public LabOrderController(
            LabOrderService labOrderService) {

        this.labOrderService = labOrderService;
    }

    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR')")
    @PostMapping
    public ResponseEntity<LabOrderDTO> createLabOrder(
            @Valid @RequestBody LabOrderDTO dto) {
        log.info("Creating lab order");

        LabOrderDTO createdOrder =
                labOrderService.createLabOrder(dto);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(createdOrder);
    }

    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','LAB_TECH')")
    @GetMapping("/{id}")
    public ResponseEntity<LabOrderDTO> getLabOrderById(
            @PathVariable UUID id) {
        log.debug("Fetching lab order");

        return ResponseEntity.ok(
                labOrderService.getLabOrderById(id)
        );
    }

    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','LAB_TECH')")
    @GetMapping("/visit/{visitId}")
    public ResponseEntity<List<LabOrderDTO>>
    getLabOrdersByVisitId(
            @PathVariable UUID visitId) {
        log.debug("Fetching lab orders by visit");

        return ResponseEntity.ok(labOrderService.getLabOrdersByVisitId(visitId));
    }

    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','LAB_TECH')")
    @GetMapping("/visit/{visitId}/status/{status}")
    public ResponseEntity<List<LabOrderDTO>>
    getLabOrdersByVisitIdAndStatus(
            @PathVariable UUID visitId,
            @PathVariable LabOrderStatus status) {
        log.debug("Fetching lab orders by visit and status");

        return ResponseEntity.ok(labOrderService.getLabOrdersByVisitIdAndStatus(visitId, status));
    }

    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR')")
    @PutMapping("/{id}")
    public ResponseEntity<LabOrderDTO> updateLabOrder(
            @PathVariable UUID id,
            @Valid @RequestBody LabOrderDTO dto) {
        log.info("Updating lab order");

        return ResponseEntity.ok(labOrderService.updateLabOrder(id, dto));
    }

    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLabOrder(
            @PathVariable UUID id) {
        log.info("Deleting lab order");

        labOrderService.deleteLabOrder(id);

        return ResponseEntity.noContent().build();
    }
}
