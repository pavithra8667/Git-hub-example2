package com.infinite.ehrSystem.vaccination.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@Entity
@Table(name = "vaccine_master")
@Getter
@Setter
@NoArgsConstructor
public class VaccineMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(unique = true, nullable = false)
    private String vaccineName;

    private Integer maxDoses;

    private Integer intervalValue;

    private String intervalUnit; // DAYS, MONTHS, YEARS

    private Boolean active;
}
