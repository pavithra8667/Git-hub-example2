package com.infinite.ehrSystem.vaccination.service;

import com.infinite.ehrSystem.vaccination.dto.VaccinationDTO;
import com.infinite.ehrSystem.vaccination.entity.VaccineMaster;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public interface VaccinationService {

    VaccinationDTO saveVaccination(VaccinationDTO dto);
    List<VaccinationDTO> getVaccinationsByPatientId(UUID patientId);
    VaccinationDTO getVaccinationById(UUID vaccinationId);
    VaccinationDTO updateVaccination(UUID vaccinationId,VaccinationDTO dto);
    void deleteVaccination(UUID vaccinationId);

    List<VaccineMaster> getActiveVaccines();
    int calculateNextDoseNumber(UUID patientId, String vaccineName);
    LocalDate calculateNextDueDate(String vaccineName, LocalDate administeredDate, int doseNumber);
}