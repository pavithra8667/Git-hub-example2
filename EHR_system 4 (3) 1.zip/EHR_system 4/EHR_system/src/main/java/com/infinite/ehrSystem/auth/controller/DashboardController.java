package com.infinite.ehrSystem.auth.controller;

import com.infinite.ehrSystem.labResults.service.LabOrderService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    private final LabOrderService labOrderService;

    public DashboardController(LabOrderService labOrderService) {
        this.labOrderService = labOrderService;
    }

    @GetMapping("/dashboard")
    public String dashboard(
            Authentication authentication,
            Model model) {

        System.out.println("DASHBOARD HIT");

        if (authentication != null) {

            String username = authentication.getName();

            String role = authentication
                    .getAuthorities()
                    .stream()
                    .findFirst()
                    .map(authority ->
                            authority.getAuthority()
                                    .replace("ROLE_", "")
                    )
                    .orElse("");

            System.out.println(
                    "USERNAME = " + username
            );

            System.out.println(
                    "ROLE = " + role
            );

            model.addAttribute(
                    "username",
                    username
            );

            model.addAttribute(
                    "role",
                    role
            );

            if ("LAB_TECH".equals(role)) {
                model.addAttribute("labOrders", labOrderService.getAllLabOrders());
            }
        }

        return "dashboard";
    }
}