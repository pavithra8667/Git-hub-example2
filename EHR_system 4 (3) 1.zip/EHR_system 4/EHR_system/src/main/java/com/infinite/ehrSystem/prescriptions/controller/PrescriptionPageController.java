package com.infinite.ehrSystem.prescriptions.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.infinite.ehrSystem.allergy.service.AllergyService;
import com.infinite.ehrSystem.prescriptions.dto.PrescriptionDTO;
import com.infinite.ehrSystem.prescriptions.dto.PrescriptionItemDTO;
import com.infinite.ehrSystem.prescriptions.service.PrescriptionService;
import com.infinite.ehrSystem.visit.repository.VisitRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Controller
@Log4j2
@RequestMapping("/prescriptions")
@RequiredArgsConstructor
public class PrescriptionPageController {

    private final PrescriptionService prescriptionService;
    private final VisitRepository visitRepository;
    private final AllergyService allergyService;

    @GetMapping("/new")
    @PreAuthorize("hasRole('DOCTOR')")
    public String newPrescription(
            @RequestParam UUID visitId,
            Model model) {
        log.info("Creating prescription from page");

        visitRepository.findById(visitId).ifPresent(v -> model.addAttribute("allergies",
                allergyService.getAllergies(v.getPatientId())));
        model.addAttribute("visitId", visitId);

        return "prescription/prescription-form";
    }


    @PostMapping("/save")
    @PreAuthorize("hasRole('DOCTOR')")
    public String savePrescription(
            @RequestParam UUID visitId,
            @RequestParam("medicineName") List<String> medicineNames,
            @RequestParam("dosage") List<String> dosages,
            @RequestParam("frequency") List<String> frequencies,
            @RequestParam("durationDays") List<Integer> durations,
            Model model) {

        List<PrescriptionItemDTO> items = new ArrayList<>();

        for (int i = 0; i < medicineNames.size(); i++) {

            PrescriptionItemDTO item =
                    new PrescriptionItemDTO();

            item.setMedicineName(
                    medicineNames.get(i)
            );

            item.setDosage(
                    dosages.get(i)
            );

            item.setFrequency(
                    frequencies.get(i)
            );

            item.setDurationDays(
                    durations.get(i)
            );

            items.add(item);
        }

        PrescriptionDTO dto =
                new PrescriptionDTO();

        dto.setVisitId(visitId);
        dto.setItems(items);

        try {

            prescriptionService.createPrescription(dto);

            return "redirect:/prescriptions?visitId=" + visitId;

        } catch (IllegalStateException e) {
            log.warn("Prescription could not be created because the request was invalid");

            model.addAttribute(
                    "errorMessage",
                    e.getMessage()
            );

            visitRepository.findById(visitId).ifPresent(v -> model.addAttribute("allergies",
                    allergyService.getAllergies(v.getPatientId())));

            model.addAttribute(
                    "visitId",
                    visitId
            );

            // Keep entered medicine values
            model.addAttribute(
                    "medicineNames",
                    medicineNames
            );

            model.addAttribute(
                    "dosages",
                    dosages
            );

            model.addAttribute(
                    "frequencies",
                    frequencies
            );

            model.addAttribute(
                    "durations",
                    durations
            );

            return "prescription/prescription-form";
        }
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','PATIENT')")
    public String listPrescriptions(
            @RequestParam UUID visitId,
            Model model) {

        model.addAttribute(
                "prescriptions",
                prescriptionService
                        .getPrescriptionsByVisitId(visitId)
        );

        model.addAttribute("visitId", visitId);

        // Resolve patient id and doctor id for links
        visitRepository.findById(visitId).ifPresent(v -> {
            model.addAttribute("patientId", v.getPatientId());
            model.addAttribute("doctorId", v.getDoctorId());
        });

        return "prescription/prescription-list";
    }

    @GetMapping("/view/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','PATIENT')")
    public String viewPrescription(
            @PathVariable UUID id,
            Model model) {

        model.addAttribute(
                "prescription",
                prescriptionService
                        .getPrescriptionById(id)
        );

        return "prescription/prescription-view";
    }

    @PostMapping("/delete/{id}")
    @PreAuthorize("hasRole('DOCTOR')")
    public String deletePrescription(
            @PathVariable UUID id,
            @RequestParam UUID visitId) {
        log.info("Deleting prescription from page");

        prescriptionService.deletePrescription(id);

        return "redirect:/prescriptions?visitId=" + visitId;
    }
}
