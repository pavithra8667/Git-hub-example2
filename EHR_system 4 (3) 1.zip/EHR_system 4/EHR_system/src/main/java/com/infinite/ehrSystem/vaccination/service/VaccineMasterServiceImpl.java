package com.infinite.ehrSystem.vaccination.service;

import com.infinite.ehrSystem.vaccination.entity.VaccineMaster;
import com.infinite.ehrSystem.vaccination.repository.VaccineMasterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class VaccineMasterServiceImpl
        implements VaccineMasterService {

    @Autowired
    private VaccineMasterRepository repository;

    @Override
    public VaccineMaster saveVaccine(VaccineMaster vaccine) {
        return repository.save(vaccine);
    }

    @Override
    public List<VaccineMaster> getAllVaccines() {
        return repository.findAll();
    }

    @Override
    public VaccineMaster getVaccineById(UUID id) {

        return repository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Vaccine not found"));
    }

    @Override
    public VaccineMaster updateVaccine(
            UUID id,
            VaccineMaster vaccine) {

        VaccineMaster existing =
                getVaccineById(id);

        existing.setVaccineName(
                vaccine.getVaccineName());

        existing.setMaxDoses(
                vaccine.getMaxDoses());

        existing.setIntervalValue(
                vaccine.getIntervalValue());

        existing.setIntervalUnit(
                vaccine.getIntervalUnit());

        existing.setActive(
                vaccine.getActive());

        return repository.save(existing);
    }

    @Override
    public void deleteVaccine(UUID id) {

        repository.deleteById(id);
    }
}