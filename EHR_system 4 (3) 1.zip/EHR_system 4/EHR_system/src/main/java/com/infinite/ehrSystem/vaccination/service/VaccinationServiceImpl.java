package com.infinite.ehrSystem.vaccination.service;

import com.infinite.ehrSystem.patient.entity.Patient;
import com.infinite.ehrSystem.patient.repository.PatientRepository;
import com.infinite.ehrSystem.vaccination.dto.VaccinationDTO;
import com.infinite.ehrSystem.vaccination.entity.Vaccination;
import com.infinite.ehrSystem.vaccination.entity.VaccineMaster;
import com.infinite.ehrSystem.vaccination.repository.VaccinationRepository;
import com.infinite.ehrSystem.vaccination.repository.VaccineMasterRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
public class VaccinationServiceImpl implements VaccinationService {

    @Autowired
    private VaccinationRepository vaccinationRepository;

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private VaccineMasterRepository vaccineMasterRepository;

    @Override
    public VaccinationDTO saveVaccination(VaccinationDTO dto) {

        if (dto.getPatientId() == null) {
            throw new IllegalArgumentException("Patient ID is required");
        }

        if (dto.getVaccineName() == null
                || dto.getVaccineName().trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Vaccine name is required");
        }

        if (dto.getAdministeredDate() == null) {
            throw new IllegalArgumentException(
                    "Administered date is required");
        }

        if (dto.getAdministeredDate().isAfter(LocalDate.now())) {
            throw new IllegalArgumentException(
                    "Administered date cannot be in the future");
        }

        String vaccineName = dto.getVaccineName().trim();

        Patient patient = patientRepository
                .findById(dto.getPatientId())
                .orElseThrow(() ->
                        new IllegalArgumentException("Patient not found with ID: " + dto.getPatientId()));

        List<Vaccination> previousDoses =
                vaccinationRepository
                        .findByPatientIdAndVaccineNameOrderByDoseNumberDesc(dto.getPatientId(), vaccineName);

        int nextDoseNumber;

        if (previousDoses.isEmpty()) {
            nextDoseNumber = 1;
        } else {
            nextDoseNumber =
                    previousDoses.get(0).getDoseNumber() + 1;
        }

        VaccineMaster vaccineMaster =
                vaccineMasterRepository
                        .findByVaccineNameIgnoreCase(vaccineName)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Vaccine not configured: "
                                                + vaccineName));

        Integer maxDoses = vaccineMaster.getMaxDoses();
        if (maxDoses != null && previousDoses.size() >= maxDoses) {
            throw new IllegalArgumentException(
                    "Already reached maximum dose for this vaccination.");
        }

        Vaccination vaccination = new Vaccination();

        vaccination.setPatient(patient);
        vaccination.setVaccineName(vaccineName);
        vaccination.setDoseNumber(nextDoseNumber);
        vaccination.setAdministeredDate(
                dto.getAdministeredDate());
        vaccination.setAdministeredBy(
                dto.getAdministeredBy());

        vaccination.setNextDueDate(
                calculateNextDueDate(
                        vaccineMaster,
                        dto.getAdministeredDate(),
                        nextDoseNumber));

        Vaccination saved =
                vaccinationRepository.save(vaccination);

        return convertToDTO(saved);
    }

    @Override
    public List<VaccinationDTO> getVaccinationsByPatientId(
            UUID patientId) {

        if (patientId == null) {
            throw new IllegalArgumentException(
                    "Patient ID is required");
        }

        return vaccinationRepository
                .findByPatientId(patientId)
                .stream()
                .map(this::convertToDTO)
                .toList();
    }

    @Override
    public VaccinationDTO getVaccinationById(
            UUID vaccinationId) {

        Vaccination vaccination =
                vaccinationRepository.findById(vaccinationId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Vaccination not found with ID: "
                                                + vaccinationId));

        return convertToDTO(vaccination);
    }

    @Override
    public VaccinationDTO updateVaccination(
            UUID vaccinationId,
            VaccinationDTO dto) {

        Vaccination vaccination =
                vaccinationRepository.findById(vaccinationId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Vaccination not found with ID: "
                                                + vaccinationId));

        if (dto.getVaccineName() != null
                && !dto.getVaccineName().trim().isEmpty()) {

            vaccination.setVaccineName(
                    dto.getVaccineName().trim());
        }

        if (dto.getAdministeredDate() != null) {

            vaccination.setAdministeredDate(
                    dto.getAdministeredDate());

            VaccineMaster vaccineMaster =
                    vaccineMasterRepository
                            .findByVaccineNameIgnoreCase(
                                    vaccination.getVaccineName())
                            .orElseThrow(() ->
                                    new IllegalArgumentException(
                                            "Vaccine not configured: "
                                                    + vaccination.getVaccineName()));

            vaccination.setNextDueDate(
                    calculateNextDueDate(
                            vaccineMaster,
                            dto.getAdministeredDate(),
                            vaccination.getDoseNumber()));
        }

        vaccination.setAdministeredBy(
                dto.getAdministeredBy());

        Vaccination updated =
                vaccinationRepository.save(vaccination);

        return convertToDTO(updated);
    }

    @Override
    public void deleteVaccination(UUID vaccinationId) {

        Vaccination vaccination =
                vaccinationRepository.findById(vaccinationId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Vaccination not found with ID: "
                                                + vaccinationId));

        vaccinationRepository.delete(vaccination);
    }

    @Override
    public List<VaccineMaster> getActiveVaccines() {
        return vaccineMasterRepository.findAll()
                .stream()
                .filter(v -> Boolean.TRUE.equals(v.getActive()))
                .toList();
    }

    @Override
    public int calculateNextDoseNumber(UUID patientId, String vaccineName) {
        if (patientId == null) {
            return 1;
        }

        if (vaccineName == null || vaccineName.isBlank()) {
            return 1;
        }

        List<Vaccination> previousDoses = vaccinationRepository
                .findByPatientIdAndVaccineNameOrderByDoseNumberDesc(patientId, vaccineName.trim());

        return previousDoses.isEmpty() ? 1 : previousDoses.get(0).getDoseNumber() + 1;
    }

    @Override
    public LocalDate calculateNextDueDate(String vaccineName, LocalDate administeredDate, int doseNumber) {
        if (vaccineName == null || vaccineName.isBlank() || administeredDate == null) {
            return null;
        }

        VaccineMaster vaccineMaster = vaccineMasterRepository
                .findByVaccineNameIgnoreCase(vaccineName)
                .orElse(null);

        if (vaccineMaster == null) {
            return null;
        }

        Integer maxDoses = vaccineMaster.getMaxDoses();
        if (maxDoses != null && doseNumber >= maxDoses) {
            return null;
        }

        String intervalUnit = vaccineMaster.getIntervalUnit();
        Integer intervalValue = vaccineMaster.getIntervalValue();

        if (intervalValue == null) {
            return null;
        }

        if ("DAYS".equalsIgnoreCase(intervalUnit)) {
            return administeredDate.plusDays(intervalValue);
        }
        if ("MONTHS".equalsIgnoreCase(intervalUnit)) {
            return administeredDate.plusMonths(intervalValue);
        }
        if ("YEARS".equalsIgnoreCase(intervalUnit)) {
            return administeredDate.plusYears(intervalValue);
        }

        throw new IllegalArgumentException("Unsupported interval unit: " + intervalUnit);
    }

    private LocalDate calculateNextDueDate(
            VaccineMaster vaccine,
            LocalDate administeredDate,
            int doseNumber) {

        if (doseNumber >= vaccine.getMaxDoses()) {
            return null;
        }

        String intervalUnit =
                vaccine.getIntervalUnit();

        if ("DAYS".equalsIgnoreCase(intervalUnit)) {
            return administeredDate.plusDays(
                    vaccine.getIntervalValue());
        }

        if ("MONTHS".equalsIgnoreCase(intervalUnit)) {
            return administeredDate.plusMonths(
                    vaccine.getIntervalValue());
        }

        if ("YEARS".equalsIgnoreCase(intervalUnit)) {
            return administeredDate.plusYears(
                    vaccine.getIntervalValue());
        }

        throw new IllegalArgumentException(
                "Unsupported interval unit: "
                        + intervalUnit);
    }

    private VaccinationDTO convertToDTO(
            Vaccination entity) {

        VaccinationDTO dto =
                new VaccinationDTO();

        dto.setId(entity.getId());

        if (entity.getPatient() != null) {
            dto.setPatientId(
                    entity.getPatient().getId());
        }

        dto.setVaccineName(
                entity.getVaccineName());

        dto.setDoseNumber(
                entity.getDoseNumber());

        dto.setAdministeredDate(
                entity.getAdministeredDate());

        dto.setAdministeredBy(
                entity.getAdministeredBy());

        dto.setNextDueDate(
                entity.getNextDueDate());

        return dto;
    }
}