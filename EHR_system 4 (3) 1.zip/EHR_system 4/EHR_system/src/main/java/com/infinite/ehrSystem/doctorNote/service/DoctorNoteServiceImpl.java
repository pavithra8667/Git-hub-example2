package com.infinite.ehrSystem.doctorNote.service;

import com.infinite.ehrSystem.doctorNote.dto.DoctorNoteDTO;
import com.infinite.ehrSystem.doctorNote.entity.DoctorNote;
import com.infinite.ehrSystem.doctorNote.repository.DoctorNoteRepository;
import com.infinite.ehrSystem.visit.entity.Visit;
import com.infinite.ehrSystem.visit.repository.VisitRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class DoctorNoteServiceImpl implements DoctorNoteService {

    @Autowired
    private DoctorNoteRepository doctorNoteRepository;

    @Autowired
    private VisitRepository visitRepository;

    @Autowired
    private com.infinite.ehrSystem.auth.repository.UserRepository userRepository;

    @Autowired
    private com.infinite.ehrSystem.patient.repository.PatientRepository patientRepository;

    @Override
    public DoctorNoteDTO saveDoctorNote(DoctorNoteDTO dto) {

        if (dto.getVisitId() == null) {
            throw new IllegalArgumentException("Visit ID is required");
        }

        if (dto.getDoctorId() == null) {
            throw new IllegalArgumentException("Doctor ID is required");
        }

        if (dto.getNoteType() == null ||
                dto.getNoteType().trim().isEmpty()) {

            throw new IllegalArgumentException("Note type is required");
        }

        if (dto.getNoteText() == null ||
                dto.getNoteText().trim().isEmpty()) {

            throw new IllegalArgumentException("Note text is required");
        }

        if (dto.getNoteText().trim().length() < 10) {

            throw new IllegalArgumentException(
                    "Note text must contain at least 10 characters");
        }

        Visit visit = visitRepository.findById(dto.getVisitId())
                .orElseThrow(() ->
                        new EntityNotFoundException(
                                "Visit not found with id : "
                                        + dto.getVisitId()));

        if (visit.getStatus() != null && visit.getStatus().name().equals("CLOSED")) {
            throw new IllegalArgumentException(
                    "Cannot add doctor notes to a closed visit");
        }

        DoctorNote doctorNote = new DoctorNote();

        doctorNote.setVisit(visit);
        doctorNote.setDoctorId(dto.getDoctorId());
        doctorNote.setNoteType(dto.getNoteType().trim());
        doctorNote.setNoteText(dto.getNoteText().trim());
        doctorNote.setCreatedAt(LocalDateTime.now());

        DoctorNote savedNote =
                doctorNoteRepository.save(doctorNote);

        return convertToDTO(savedNote);
    }

    @Override
    public List<DoctorNoteDTO> getNotesByVisitId(UUID visitId) {

        if (visitId == null) {
            throw new IllegalArgumentException(
                    "Visit ID is required");
        }

        return doctorNoteRepository.findByVisit_Id(visitId)
                .stream()
                .map(this::convertToDTO)
                .toList();
    }

    @Override
    public DoctorNoteDTO getDoctorNoteById(UUID id) {

        DoctorNote doctorNote =
                doctorNoteRepository.findById(id)
                        .orElseThrow(() ->
                                new EntityNotFoundException(
                                        "Doctor Note not found"));

        return convertToDTO(doctorNote);
    }

    @Override
    public UUID getDoctorIdForVisit(UUID visitId) {
        Visit visit = visitRepository.findById(visitId)
                .orElseThrow(() -> new EntityNotFoundException("Visit not found with id : " + visitId));
        return visit.getDoctorId();
    }

    @Override
    public List<DoctorNoteDTO> getNotesByPatientId(UUID patientId) {
        if (patientId == null) {
            throw new IllegalArgumentException("Patient ID is required");
        }

        List<Visit> visits = visitRepository.findByPatientId(patientId);

        return visits.stream()
                .flatMap(visit -> doctorNoteRepository.findByVisit_Id(visit.getId()).stream())
                .map(this::convertToDTO)
                .toList();
    }

    @Override
    public Map<String, Object> getVisitDetailsForView(UUID visitId, UUID doctorId) {
        Map<String, Object> details = new HashMap<>();

        Visit visit = visitRepository.findById(visitId)
                .orElseThrow(() -> new EntityNotFoundException("Visit not found with id: " + visitId));

        String patientName = getPatientName(visit.getPatientId());
        String doctorName = getDoctorName(visit.getDoctorId());
        String visitStatus = visit.getStatus() != null ? visit.getStatus().toString() : "OPEN";

        if (doctorId == null) {
            doctorId = visit.getDoctorId();
        }

        details.put("visitId", visitId);
        details.put("patientId", visit.getPatientId());
        details.put("patientName", patientName);
        details.put("doctorId", doctorId);
        details.put("doctorName", doctorName);
        details.put("visitStatus", visitStatus);
        details.put("notes", getNotesByVisitId(visitId));

        return details;
    }

    @Override
    public Map<String, Object> getVisitDetailsForForm(UUID visitId, UUID doctorId) {
        Map<String, Object> details = new HashMap<>();

        Visit visit = visitRepository.findById(visitId)
                .orElseThrow(() -> new EntityNotFoundException("Visit not found with id: " + visitId));

        String patientName = getPatientName(visit.getPatientId());
        String doctorName = getDoctorName(visit.getDoctorId());

        details.put("visitId", visitId);
        details.put("patientId", visit.getPatientId());
        details.put("doctorId", doctorId);
        details.put("patientName", patientName);
        details.put("doctorName", doctorName);

        return details;
    }

    private String getPatientName(UUID patientId) {
        try {
            var patient = patientRepository.findById(patientId);
            if (patient.isPresent()) {
                return patient.get().getName();
            }
        } catch (Exception e) {
        }
        return "Unknown";
    }

    private String getDoctorName(UUID doctorId) {
        try {
            var doctor = userRepository.findById(doctorId);
            if (doctor.isPresent()) {
                return doctor.get().getUsername();
            }
        } catch (Exception e) {
        }
        return "Unknown";
    }

    private DoctorNoteDTO convertToDTO(
            DoctorNote doctorNote) {

        DoctorNoteDTO dto = new DoctorNoteDTO();

        dto.setId(doctorNote.getId());

        if (doctorNote.getVisit() != null) {
            Visit visit = doctorNote.getVisit();
            dto.setVisitId(visit.getId());
            dto.setPatientName(getPatientName(visit.getPatientId()));
        }

        dto.setDoctorId(doctorNote.getDoctorId());
        dto.setDoctorName(getDoctorName(doctorNote.getDoctorId()));
        dto.setNoteType(doctorNote.getNoteType());
        dto.setNoteText(doctorNote.getNoteText());
        dto.setCreatedAt(doctorNote.getCreatedAt());

        return dto;
    }
}