package com.infinite.ehrSystem.visit.controller;
import java.time.LocalDateTime;
import java.util.UUID;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.infinite.ehrSystem.auth.entity.User;
import com.infinite.ehrSystem.auth.repository.UserRepository;
import com.infinite.ehrSystem.visit.dto.VisitDTO;
import com.infinite.ehrSystem.visit.service.VisitService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Controller

@Log4j2
@RequestMapping("/visits")
@RequiredArgsConstructor
public class VisitPageController {

    private final VisitService visitService;
    private final UserRepository userRepository;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR')")
    public String listVisits(Model model) {

        model.addAttribute(
                "visits",
                visitService.getAllVisits()
        );

        return "visit/visit-list";
    }

    @GetMapping("/new")
    @PreAuthorize("hasRole('DOCTOR')")
    public String newVisit(Authentication authentication, Model model) {
        String loggedInUsername = authentication.getName();
        User currentDoctor = userRepository.findByUsername(loggedInUsername)
                .orElseThrow(() -> new IllegalStateException("Logged in doctor not found"));

        model.addAttribute("visit", new VisitDTO());
        model.addAttribute("patients", visitService.getPatientsForVisitForm());
        model.addAttribute("currentDoctor", currentDoctor);
        model.addAttribute("doctorName", currentDoctor.getUsername());
        model.addAttribute("doctorId", currentDoctor.getId());

        return "visit/visit-form";
    }

    @PostMapping("/save")
    @PreAuthorize("hasRole('DOCTOR')")

    public String saveVisit(
            @RequestParam UUID patientId,
            @RequestParam UUID doctorId,
            @RequestParam(required = false) String visitDate) {
        log.info("Creating visit from page");

        VisitDTO dto = new VisitDTO();

        dto.setPatientId(patientId);
        dto.setDoctorId(doctorId);

        if (visitDate != null && !visitDate.isBlank()) {
            dto.setVisitDate(
                    LocalDateTime.parse(visitDate)
            );
        }

        visitService.createVisit(dto);

        return "redirect:/visits";
    }

    @GetMapping("/details/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR')")
    public String visitDetails(
            @PathVariable UUID id,
            Model model) {

        model.addAttribute(
                "visit",
                visitService.getVisitById(id)
        );

        return "visit/visit-detail";
    }

    @PostMapping("/close/{id}")
    @PreAuthorize("hasRole('DOCTOR')")

    public String closeVisit(
            @PathVariable UUID id) {
        log.info("Closing visit from page");

        visitService.closeVisit(id);

        return "redirect:/visits";
    }
}
