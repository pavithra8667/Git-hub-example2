package com.infinite.ehrSystem.auth.controller;

import com.infinite.ehrSystem.auth.dto.UserCreateDto;
import com.infinite.ehrSystem.auth.service.UserManagementService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@PreAuthorize("hasRole('ADMIN')")
public class UserManagementController {

    private final UserManagementService userManagementService;

    public UserManagementController(UserManagementService userManagementService) {
        this.userManagementService = userManagementService;
    }

    @GetMapping("/users")
    public String userList(Model model) {
        model.addAttribute("users", userManagementService.getAllStaffUsers());
        return "user-list";
    }

    @GetMapping("/users/new")
    public String showUserForm(Model model) {
        model.addAttribute("userForm", new UserCreateDto());
        model.addAttribute("roles", List.of("ADMIN", "DOCTOR", "LAB_TECH"));
        return "user-form";
    }

    @PostMapping("/users")
    public String createUser(
            @Valid @ModelAttribute("userForm") UserCreateDto userCreateDto,
            BindingResult bindingResult,
            Model model,
            RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            model.addAttribute("roles", List.of("ADMIN", "DOCTOR", "LAB_TECH"));
            return "user-form";
        }

        try {
            userManagementService.createStaffUser(userCreateDto);
            redirectAttributes.addFlashAttribute("successMessage", "User account created successfully");
            return "redirect:/users";
        } catch (RuntimeException exception) {
            model.addAttribute("roles", List.of("ADMIN", "DOCTOR", "LAB_TECH"));
            model.addAttribute("errorMessage", exception.getMessage());
            return "user-form";
        }
    }
}
