package com.infinite.ehrSystem.patientPortal.service;

import com.infinite.ehrSystem.allergy.service.AllergyService;
import com.infinite.ehrSystem.diagnosis.service.DiagnosisService;
import com.infinite.ehrSystem.doctorNote.dto.DoctorNoteDTO;
import com.infinite.ehrSystem.doctorNote.service.DoctorNoteService;
import com.infinite.ehrSystem.labResults.service.LabResultService;
import com.infinite.ehrSystem.medicalhistory.service.MedicalHistoryService;
import com.infinite.ehrSystem.patient.dto.PatientDto;
import com.infinite.ehrSystem.patient.entity.Patient;
import com.infinite.ehrSystem.patient.repository.PatientRepository;
import com.infinite.ehrSystem.patientPortal.dto.PatientPortalDTO;
import com.infinite.ehrSystem.prescriptions.service.PrescriptionService;
import com.infinite.ehrSystem.vaccination.service.VaccinationService;
import com.infinite.ehrSystem.medicalhistory.dto.MedicalHistoryDto;
import com.infinite.ehrSystem.allergy.dto.AllergyDTO;
import com.infinite.ehrSystem.vaccination.dto.VaccinationDTO;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class PatientPortalServiceImpl implements PatientPortalService {

    private final PatientRepository patientRepository;
    private final MedicalHistoryService medicalHistoryService;
    private final AllergyService allergyService;
    private final DiagnosisService diagnosisService;
    private final LabResultService labResultService;
    private final PrescriptionService prescriptionService;
    private final VaccinationService vaccinationService;
    private final DoctorNoteService doctorNoteService;

    public PatientPortalServiceImpl(
            PatientRepository patientRepository,
            MedicalHistoryService medicalHistoryService,
            AllergyService allergyService,
            DiagnosisService diagnosisService,
            LabResultService labResultService,
            PrescriptionService prescriptionService,
            VaccinationService vaccinationService,
            DoctorNoteService doctorNoteService
    ) {
        this.patientRepository = patientRepository;
        this.medicalHistoryService = medicalHistoryService;
        this.allergyService = allergyService;
        this.diagnosisService = diagnosisService;
        this.labResultService = labResultService;
        this.prescriptionService = prescriptionService;
        this.vaccinationService = vaccinationService;
        this.doctorNoteService = doctorNoteService;
    }

    @Override
    public PatientPortalDTO getPatientPortal(String username) {
        if (username == null || username.isBlank()) {
            return null;
        }

        Optional<Patient> patientOpt = patientRepository.findByPortalUser_Username(username);
        if (patientOpt.isEmpty()) {
            patientOpt = patientRepository.findByPatientCode(username);
        }

        if (patientOpt.isEmpty()) {
            return null;
        }

        return buildPortal(patientOpt.get());
    }

    @Override
    public PatientPortalDTO getPatientPortalByPatientId(UUID patientId) {
        if (patientId == null) return null;

        Optional<Patient> patientOpt = patientRepository.findById(patientId);
        if (patientOpt.isEmpty()) return null;

        return buildPortal(patientOpt.get());
    }

    private PatientPortalDTO buildPortal(Patient patient) {
        UUID patientId = patient.getId();

        PatientDto patientDto = new PatientDto();
        patientDto.setId(patient.getId());
        patientDto.setPatientCode(patient.getPatientCode());
        patientDto.setName(patient.getName());
        patientDto.setDob(patient.getDob());
        patientDto.setGender(patient.getGender());
        patientDto.setPhone(patient.getPhone());
        patientDto.setGuardianName(patient.getGuardianName());
        patientDto.setBloodGroup(patient.getBloodGroup());

        List<MedicalHistoryDto> histories = medicalHistoryService.getHistory(patientId);
        List<AllergyDTO> allergies = allergyService.getAllergies(patientId);
        List<VaccinationDTO> vaccinations = vaccinationService.getVaccinationsByPatientId(patientId);
        List<DoctorNoteDTO> doctorNotes = doctorNoteService.getNotesByPatientId(patientId);

        PatientPortalDTO portalDTO = new PatientPortalDTO();
        portalDTO.setPatient(patientDto);
        portalDTO.setMedicalHistories(histories);
        portalDTO.setAllergies(allergies);
        portalDTO.setVaccinations(vaccinations);
        portalDTO.setDoctorNotes(doctorNotes);
        portalDTO.setDiagnoses(List.of());
        portalDTO.setLabResults(List.of());
        portalDTO.setPrescriptions(List.of());

        return portalDTO;
    }
}