package com.infinite.ehrSystem.vaccination.controller;

import com.infinite.ehrSystem.auth.entity.User;
import com.infinite.ehrSystem.auth.repository.UserRepository;
import com.infinite.ehrSystem.patient.entity.Patient;
import com.infinite.ehrSystem.patient.repository.PatientRepository;
import com.infinite.ehrSystem.vaccination.dto.VaccinationDTO;
import com.infinite.ehrSystem.vaccination.entity.VaccineMaster;
import com.infinite.ehrSystem.vaccination.service.VaccinationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping({"/vaccination-ui"})
public class VaccinationViewController {

    @Autowired
    private VaccinationService vaccinationService;
    @Autowired
    private PatientRepository patientRepository;
    @Autowired
    private UserRepository userRepository;

    @GetMapping("/new")
    public String showCreateForm(@RequestParam(required = false) UUID patientId,
                                @RequestParam(required = false) String patientCode,
                                @RequestParam(required = false) UUID visitId,
                                @RequestParam(required = false) UUID doctorId,
                                @RequestParam(required = false) String doctorName,
                                Model model) {
        String resolvedPatientCode = "";
        String resolvedPatientName = "";

        if (patientId != null) {
            Patient patient = patientRepository.findById(patientId).orElse(null);
            if (patient != null) {
                resolvedPatientCode = patient.getPatientCode();
                resolvedPatientName = patient.getName();
            }
        }
        // If no patientId, try to resolve from patientCode
        else if (patientCode != null && !patientCode.isBlank()) {
            Patient patient = patientRepository.findByPatientCode(patientCode)
                    .orElse(null);
            if (patient != null) {
                patientId = patient.getId();
                resolvedPatientCode = patient.getPatientCode();
                resolvedPatientName = patient.getName();
            }
        }

        String resolvedDoctorName = doctorName;
        if ((resolvedDoctorName == null || resolvedDoctorName.isBlank()) && doctorId != null) {
            User doctor = userRepository.findById(doctorId).orElse(null);
            if (doctor != null && doctor.getUsername() != null && !doctor.getUsername().isBlank()) {
                resolvedDoctorName = doctor.getUsername();
            }
        }

        model.addAttribute("patientId", patientId);
        model.addAttribute("patientCode", resolvedPatientCode);
        model.addAttribute("patientName", resolvedPatientName);
        model.addAttribute("visitId", visitId);
        model.addAttribute("doctorId", doctorId);
        model.addAttribute("doctorName", resolvedDoctorName);
        model.addAttribute("administeredBy", resolvedDoctorName);
        model.addAttribute("vaccinationDTO", new VaccinationDTO());

        // Load active vaccines for the dropdown
        List<VaccineMaster> vaccines = vaccinationService.getActiveVaccines();
        model.addAttribute("vaccines", vaccines);

        // default administered date for the form
        model.addAttribute("administeredDateDefault", LocalDate.now());

        return "vaccination-form";
    }

    @PostMapping("/save")
    public String saveVaccination(@RequestParam(required = false) UUID patientId,
                                 @RequestParam(required = false) String patientCode,
                                 @RequestParam(required = false) UUID visitId,
                                 @RequestParam(required = false) UUID doctorId,
                                 @RequestParam String vaccineName,
                                 @RequestParam Integer doseNumber,
                                 @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate administeredDate,
                                 @RequestParam(required = false) String administeredBy,
                                 @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate nextDueDate,
                                 Model model) {

        try {
            if (patientId == null && patientCode != null && !patientCode.isBlank()) {
                Patient patient = patientRepository.findByPatientCode(patientCode).orElse(null);
                if (patient != null) {
                    patientId = patient.getId();
                }
            }

            if (patientId == null) {
                model.addAttribute("errorMessage", "Patient is required");
                return "vaccination-form";
            }

            VaccinationDTO dto = new VaccinationDTO();
            dto.setPatientId(patientId);
            dto.setVaccineName(vaccineName);
            dto.setDoseNumber(doseNumber);
            dto.setAdministeredDate(administeredDate);
            dto.setAdministeredBy(administeredBy);
            dto.setNextDueDate(nextDueDate);

            vaccinationService.saveVaccination(dto);

            String redirectUrl = "/vaccination-ui/list?patientId=" + patientId;
            if (visitId != null) {
                redirectUrl += "&visitId=" + visitId;
            }
            if (doctorId != null) {
                redirectUrl += "&doctorId=" + doctorId;
            }
            if (administeredBy != null && !administeredBy.isBlank()) {
                redirectUrl += "&doctorName=" + java.net.URLEncoder.encode(administeredBy, java.nio.charset.StandardCharsets.UTF_8);
            }
            return "redirect:" + redirectUrl;
        } catch (IllegalArgumentException e) {
            if (patientId != null) {
                Patient patient = patientRepository.findById(patientId).orElse(null);
                if (patient != null) {
                    model.addAttribute("patientId", patient.getId());
                    model.addAttribute("patientCode", patient.getPatientCode());
                    model.addAttribute("patientName", patient.getName());
                } else {
                    model.addAttribute("patientId", patientId);
                    model.addAttribute("patientCode", patientCode);
                    model.addAttribute("patientName", "");
                }
            } else {
                model.addAttribute("patientId", null);
                model.addAttribute("patientCode", patientCode);
                model.addAttribute("patientName", "");
            }

            String resolvedDoctorName = administeredBy;
            if ((resolvedDoctorName == null || resolvedDoctorName.isBlank()) && doctorId != null) {
                User doctor = userRepository.findById(doctorId).orElse(null);
                if (doctor != null && doctor.getUsername() != null && !doctor.getUsername().isBlank()) {
                    resolvedDoctorName = doctor.getUsername();
                }
            }

            model.addAttribute("visitId", visitId);
            model.addAttribute("doctorId", doctorId);
            model.addAttribute("doctorName", resolvedDoctorName);
            model.addAttribute("administeredBy", resolvedDoctorName);
            model.addAttribute("vaccinationDTO", new VaccinationDTO());
            model.addAttribute("vaccines", vaccinationService.getActiveVaccines());
            model.addAttribute("administeredDateDefault", LocalDate.now());
            model.addAttribute("errorMessage", e.getMessage());
            return "vaccination-form";
        }
    }

    @GetMapping("/compute")
    public org.springframework.http.ResponseEntity<?> computeNextDoseAndDue(
            @RequestParam(required = false) UUID patientId,
            @RequestParam String vaccineName,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate administeredDate) {


        int nextDoseNumber = vaccinationService.calculateNextDoseNumber(patientId, vaccineName);
        LocalDate nextDueDate = vaccinationService.calculateNextDueDate(vaccineName, administeredDate, nextDoseNumber);

        java.util.Map<String, Object> result = new java.util.HashMap<>();
        result.put("nextDoseNumber", nextDoseNumber);
        result.put("nextDueDate", nextDueDate == null ? null : nextDueDate.toString());

        return org.springframework.http.ResponseEntity.ok(result);
    }

    @GetMapping("/list")
    public String listVaccinations(@RequestParam(required = false) UUID patientId,
                                  @RequestParam(required = false) UUID visitId,
                                  @RequestParam(required = false) UUID doctorId,
                                  @RequestParam(required = false) String doctorName,
                                  Model model) {
        List<VaccinationDTO> vaccinations = (patientId != null)
                ? vaccinationService.getVaccinationsByPatientId(patientId)
                : List.of();

        String patientCode = "";
        String patientName = "";
        Integer age = null;
        String gender = "";

        if (patientId != null) {
            Patient patient = patientRepository.findById(patientId).orElse(null);
            if (patient != null) {
                patientCode = patient.getPatientCode();
                patientName = patient.getName();
                gender = patient.getGender();
                if (patient.getDob() != null) {
                    age = LocalDate.now().getYear() - patient.getDob().getYear();
                }
            }
        }

        if ((doctorName == null || doctorName.isBlank()) && doctorId != null) {
            User doctor = userRepository.findById(doctorId).orElse(null);
            if (doctor != null) {
                doctorName = doctor.getUsername();
            }
        }

        model.addAttribute("vaccinations", vaccinations);
        model.addAttribute("patientId", patientId);
        model.addAttribute("patientCode", patientCode);
        model.addAttribute("patientName", patientName);
        model.addAttribute("age", age);
        model.addAttribute("gender", gender);
        model.addAttribute("doctorId", doctorId);
        model.addAttribute("doctorName", doctorName);
        model.addAttribute("visitId", visitId != null ? visitId : null);
        return "vaccination-list";
    }

    @GetMapping("/list/patient")
    public String listPatientVaccinations(@RequestParam(required = false) UUID patientId, Model model) {
        List<VaccinationDTO> vaccinations = (patientId != null)
                ? vaccinationService.getVaccinationsByPatientId(patientId)
                : List.of();

        String patientCode = "";
        String patientName = "";
        Integer age = null;
        String gender = "";

        if (patientId != null) {
            Patient patient = patientRepository.findById(patientId).orElse(null);
            if (patient != null) {
                patientCode = patient.getPatientCode();
                patientName = patient.getName();
                gender = patient.getGender();
                if (patient.getDob() != null) {
                    age = LocalDate.now().getYear() - patient.getDob().getYear();
                }
            }
        }

        model.addAttribute("vaccinations", vaccinations);
        model.addAttribute("patientId", patientId);
        model.addAttribute("patientCode", patientCode);
        model.addAttribute("patientName", patientName);
        model.addAttribute("age", age);
        model.addAttribute("gender", gender);
        return "vaccination-list-patient";
    }
}
