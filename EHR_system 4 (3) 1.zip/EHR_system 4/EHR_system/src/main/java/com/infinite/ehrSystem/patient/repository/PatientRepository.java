package com.infinite.ehrSystem.patient.repository;
import com.infinite.ehrSystem.patient.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
public interface  PatientRepository extends JpaRepository<Patient, UUID>{
    boolean existsByPhone(String phone);
    boolean existsByPatientCode(String patientCode);

    Optional<Patient> findByPhone(String phone);
    Optional<Patient> findByPatientCode(String patientCode);
    Optional<Patient> findByPortalUser_Username(String username);
    Optional<Patient> findByPortalUser_Id(UUID portalUserId);
    List<Patient> findByNameContainingIgnoreCase(String name);
}
