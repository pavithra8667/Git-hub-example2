package com.infinite.ehrSystem.allergy.service;

import com.infinite.ehrSystem.allergy.dto.AllergyDTO;

import java.util.List;
import java.util.UUID;

public interface AllergyService {

    List<AllergyDTO> getAllergies(
            UUID patientId
    );

    AllergyDTO getAllergyById(UUID allergyId);

    AllergyDTO addAllergy(
            UUID patientId,
            AllergyDTO allergyDTO
    );

    AllergyDTO updateAllergy(
            UUID allergyId,
            UUID patientId,
            AllergyDTO allergyDTO
    );
}
