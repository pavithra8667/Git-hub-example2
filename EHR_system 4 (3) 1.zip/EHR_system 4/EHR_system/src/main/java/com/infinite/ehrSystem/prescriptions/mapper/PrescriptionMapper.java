package com.infinite.ehrSystem.prescriptions.mapper;

import com.infinite.ehrSystem.prescriptions.dto.PrescriptionDTO;
import com.infinite.ehrSystem.prescriptions.dto.PrescriptionItemDTO;
import com.infinite.ehrSystem.prescriptions.entity.Prescription;
import com.infinite.ehrSystem.prescriptions.entity.PrescriptionItem;
import com.infinite.ehrSystem.visit.entity.Visit;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class PrescriptionMapper {

    public PrescriptionDTO toDTO(Prescription prescription) {
        if (prescription == null) {
            return null;
        }

        List<PrescriptionItemDTO> items = new ArrayList<>();
        if (prescription.getItems() != null) {
            for (PrescriptionItem item : prescription.getItems()) {
                items.add(toItemDTO(item));
            }
        }

        return PrescriptionDTO.builder()
                .prescriptionId(prescription.getPrescriptionId())
                .visitId(prescription.getVisit() == null ? null : prescription.getVisit().getId())
                .items(items)
                .build();
    }

    public Prescription toEntity(PrescriptionDTO dto) {
        return toEntity(dto, null);
    }

    public Prescription toEntity(PrescriptionDTO dto, Visit visit) {
        if (dto == null) {
            return null;
        }

        Prescription prescription = Prescription.builder()
                .prescriptionId(dto.getPrescriptionId())
                .visit(visit)
                .build();

        List<PrescriptionItem> items = new ArrayList<>();
        if (dto.getItems() != null) {
            for (PrescriptionItemDTO itemDTO : dto.getItems()) {
                PrescriptionItem item = toItemEntity(itemDTO);
                item.setPrescription(prescription);
                items.add(item);
            }
        }
        prescription.setItems(items);
        return prescription;
    }

    private PrescriptionItemDTO toItemDTO(PrescriptionItem item) {
        return PrescriptionItemDTO.builder()
                .itemId(item.getItemId())
                .medicineName(item.getMedicineName())
                .dosage(item.getDosage())
                .frequency(item.getFrequency())
                .durationDays(item.getDurationDays())
                .build();
    }

    private PrescriptionItem toItemEntity(PrescriptionItemDTO dto) {
        return PrescriptionItem.builder()
                .itemId(dto.getItemId())
                .medicineName(dto.getMedicineName())
                .dosage(dto.getDosage())
                .frequency(dto.getFrequency())
                .durationDays(dto.getDurationDays())
                .build();
    }
}
