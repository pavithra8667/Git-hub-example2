package com.infinite.ehrSystem.vaccination.service;

import com.infinite.ehrSystem.vaccination.entity.VaccineMaster;

import java.util.List;
import java.util.UUID;

public interface VaccineMasterService {

    VaccineMaster saveVaccine(VaccineMaster vaccine);

    List<VaccineMaster> getAllVaccines();

    VaccineMaster getVaccineById(UUID id);

    VaccineMaster updateVaccine(UUID id, VaccineMaster vaccine);

    void deleteVaccine(UUID id);
}