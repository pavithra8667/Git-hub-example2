package com.infinite.ehrSystem.doctorNote.repository;

import com.infinite.ehrSystem.doctorNote.entity.DoctorNote;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface DoctorNoteRepository extends JpaRepository<DoctorNote, UUID> {

    @Query("SELECT d FROM DoctorNote d WHERE d.visit.id = :visitId ORDER BY d.createdAt ASC")
    List<DoctorNote> findByVisit_Id(@Param("visitId") UUID visitId);

}