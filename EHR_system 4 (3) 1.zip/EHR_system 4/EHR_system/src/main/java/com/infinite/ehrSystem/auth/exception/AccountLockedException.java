package com.infinite.ehrSystem.auth.exception;

public class AccountLockedException
        extends RuntimeException {

    public AccountLockedException(
            String message) {
        super(message);
    }
}
