package com.infinite.ehrSystem.patientPortal.controller;

import com.infinite.ehrSystem.auth.entity.User;
import com.infinite.ehrSystem.patientPortal.dto.PatientPortalDTO;
import com.infinite.ehrSystem.patientPortal.service.PatientPortalService;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.UUID;

@Controller
@RequestMapping("/patient-portal")
public class PatientPortalController {

    private final PatientPortalService patientPortalService;

    public PatientPortalController(PatientPortalService patientPortalService) {
        this.patientPortalService = patientPortalService;
    }

    @GetMapping
    public String dashboard(
            @RequestParam(required = false) UUID patientId,
            HttpSession session,
            Authentication authentication,
            Model model) {

        if (patientId == null && authentication != null && authentication.isAuthenticated()) {
            String username = authentication.getName();
            PatientPortalDTO portal = patientPortalService.getPatientPortal(username);
            if (portal != null && portal.getPatient() != null) {
                patientId = portal.getPatient().getId();
            }
        }

        if (patientId == null) {
            Object sessionPatientId = session.getAttribute("patientId");
            if (sessionPatientId instanceof UUID) {
                patientId = (UUID) sessionPatientId;
            }
        }

        if (patientId == null) {
            model.addAttribute("errorMessage", "Please login with your patient account to access the portal.");
            return "redirect:/patient-login?error=true";
        }

        PatientPortalDTO portal = patientPortalService.getPatientPortalByPatientId(patientId);
        model.addAttribute("portal", portal);

        if (portal != null && portal.getPatient() != null && portal.getPatient().getDob() != null) {
            java.time.LocalDate dob = portal.getPatient().getDob();
            int age = java.time.Period.between(dob, java.time.LocalDate.now()).getYears();
            model.addAttribute("age", age);
        }

        if (portal != null && portal.getVaccinations() != null) {
            model.addAttribute("vaccinationCount", portal.getVaccinations().size());
            if (!portal.getVaccinations().isEmpty()) {
                model.addAttribute("lastVaccination", portal.getVaccinations().get(portal.getVaccinations().size() - 1));
            }
        }

        if (session.getAttribute("patientId") == null && portal != null && portal.getPatient() != null) {
            session.setAttribute("patientId", portal.getPatient().getId());
            session.setAttribute("patientCode", portal.getPatient().getPatientCode());
        }

        return "portal-dashboard";
    }
}