package com.infinite.ehrSystem.labResults.mapper;

import com.infinite.ehrSystem.labResults.dto.LabResultDTO;
import com.infinite.ehrSystem.labResults.entity.LabOrder;
import com.infinite.ehrSystem.labResults.entity.LabResult;
import org.springframework.stereotype.Component;

@Component
public class LabResultMapper {

    public LabResultDTO toDTO(LabResult result) {
        return toDTO(result, null);
    }

    public LabResultDTO toDTO(LabResult result, LabOrder labOrder) {
        if (result == null) {
            return null;
        }

        return LabResultDTO.builder()
                .id(result.getId())
                .labOrderId(result.getLabOrderId())
                .resultValue(result.getResultValue())
                .unit(result.getUnit())
                .referenceRange(result.getReferenceRange())
                .flag(result.getFlag())
                .resultDate(result.getResultDate())
                .testName(labOrder == null ? null : labOrder.getTestName())
                .build();
    }

    public LabResult toEntity(LabResultDTO dto) {
        if (dto == null) {
            return null;
        }

        return LabResult.builder()
                .id(dto.getId())
                .labOrderId(dto.getLabOrderId())
                .resultValue(dto.getResultValue())
                .unit(dto.getUnit())
                .referenceRange(dto.getReferenceRange())
                .flag(dto.getFlag())
                .resultDate(dto.getResultDate())
                .build();
    }
}
