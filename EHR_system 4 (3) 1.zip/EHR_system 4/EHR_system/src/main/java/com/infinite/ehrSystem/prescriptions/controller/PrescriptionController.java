package com.infinite.ehrSystem.prescriptions.controller;

import com.infinite.ehrSystem.prescriptions.dto.PrescriptionDTO;
import com.infinite.ehrSystem.prescriptions.service.PrescriptionService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import lombok.extern.log4j.Log4j2;

import java.util.List;
import java.util.UUID;

@RestController
@Log4j2
@RequestMapping("/api/prescriptions")
public class PrescriptionController {

    private final PrescriptionService prescriptionService;

    public PrescriptionController(
            PrescriptionService prescriptionService) {

        this.prescriptionService = prescriptionService;
    }

    @PostMapping
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<PrescriptionDTO> createPrescription(
            @Valid @RequestBody PrescriptionDTO dto) {
        log.info("Creating prescription");

        PrescriptionDTO saved =
                prescriptionService.createPrescription(dto);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(saved);
    }

    @GetMapping("/{prescriptionId}")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','PATIENT')")
    public ResponseEntity<PrescriptionDTO> getPrescriptionById(
            @PathVariable UUID prescriptionId) {
        log.debug("Fetching prescription");

        return ResponseEntity.ok(
                prescriptionService.getPrescriptionById(
                        prescriptionId
                )
        );
    }

    @GetMapping("/visit/{visitId}")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','PATIENT')")
    public ResponseEntity<List<PrescriptionDTO>>
    getPrescriptionsByVisitId(
            @PathVariable UUID visitId) {
        log.debug("Fetching prescriptions by visit");

        return ResponseEntity.ok(
                prescriptionService
                        .getPrescriptionsByVisitId(visitId)
        );
    }

    @PutMapping("/{prescriptionId}")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<PrescriptionDTO> updatePrescription(
            @PathVariable UUID prescriptionId,
            @Valid @RequestBody PrescriptionDTO dto) {
        log.info("Updating prescription");

        return ResponseEntity.ok(
                prescriptionService.updatePrescription(
                        prescriptionId,
                        dto
                )
        );
    }

    @DeleteMapping("/{prescriptionId}")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<Void> deletePrescription(
            @PathVariable UUID prescriptionId) {
        log.info("Deleting prescription");

        prescriptionService.deletePrescription(
                prescriptionId
        );

        return ResponseEntity.noContent().build();
    }
}
