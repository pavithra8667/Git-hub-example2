package com.infinite.ehrSystem.auth.service;

import com.infinite.ehrSystem.auth.dto.UserCreateDto;
import com.infinite.ehrSystem.auth.entity.User;
import com.infinite.ehrSystem.patient.entity.Patient;

import java.util.List;
import java.util.UUID;

public interface UserManagementService {

    List<User> getAllStaffUsers();

    User createStaffUser(UserCreateDto userCreateDto);

    User createPatientPortalUser(Patient patient, String rawPassword);

    User findPatientPortalUserByPatientId(UUID patientId);

    // Update patient portal password
    User updatePatientPortalPassword(UUID patientId, String rawPassword);
}
