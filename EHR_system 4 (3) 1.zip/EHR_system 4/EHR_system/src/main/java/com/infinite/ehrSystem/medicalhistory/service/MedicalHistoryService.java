package com.infinite.ehrSystem.medicalhistory.service;

import com.infinite.ehrSystem.medicalhistory.dto.MedicalHistoryDto;

import java.util.List;
import java.util.UUID;

public interface MedicalHistoryService {

    List<MedicalHistoryDto> getHistory(
            UUID patientId
    );

    MedicalHistoryDto getHistoryById(UUID historyId);

    MedicalHistoryDto addHistory(
            UUID patientId,
            MedicalHistoryDto medicalHistoryDto
    );

    MedicalHistoryDto updateHistory(
            UUID historyId,
            UUID patientId,
            MedicalHistoryDto medicalHistoryDto
    );
}