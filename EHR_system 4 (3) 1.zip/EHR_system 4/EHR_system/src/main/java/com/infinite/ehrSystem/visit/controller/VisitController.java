package com.infinite.ehrSystem.visit.controller;

import com.infinite.ehrSystem.visit.dto.VisitDTO;
import com.infinite.ehrSystem.visit.service.VisitService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@PreAuthorize("hasAnyRole('ADMIN','DOCTOR')")
@Log4j2
@RequestMapping("/api/visits")
@RequiredArgsConstructor
public class VisitController {

    private final VisitService visitService;

    @PostMapping
    public ResponseEntity<VisitDTO> createVisit(
            @Valid @RequestBody VisitDTO visitDTO) {
        log.info("Creating visit");

        VisitDTO createdVisit =
                visitService.createVisit(visitDTO);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(createdVisit);
    }

    @GetMapping("/{id}")
    public ResponseEntity<VisitDTO> getVisitById(
            @PathVariable UUID id) {
        log.debug("Fetching visit");

        return ResponseEntity.ok(
                visitService.getVisitById(id)
        );
    }

    @GetMapping("/patient/{patientId}")
    public ResponseEntity<List<VisitDTO>> getVisitsByPatient(
            @PathVariable UUID patientId) {
        log.debug("Fetching visits by patient");

        return ResponseEntity.ok(
                visitService.getVisitsByPatient(patientId)
        );
    }

    @GetMapping("/doctor/{doctorId}")
    public ResponseEntity<List<VisitDTO>> getVisitsByDoctor(
            @PathVariable UUID doctorId) {
        log.debug("Fetching visits by doctor");

        return ResponseEntity.ok(
                visitService.getVisitsByDoctor(doctorId)
        );
    }
    @GetMapping
    public ResponseEntity<List<VisitDTO>>
    getAllVisits() {
        log.debug("Fetching all visits");

        return ResponseEntity.ok(
                visitService.getAllVisits()
        );
    }
    @PutMapping("/{id}/close")
    public ResponseEntity<VisitDTO> closeVisit(
            @PathVariable UUID id) {
        log.info("Closing visit");

        return ResponseEntity.ok(
                visitService.closeVisit(id)
        );
    }
}
