package com.infinite.ehrSystem.vaccination.controller;

import com.infinite.ehrSystem.vaccination.entity.VaccineMaster;
import com.infinite.ehrSystem.vaccination.service.VaccineMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping("/vaccine-master-ui")
public class VaccineMasterViewController {

    @Autowired
    private VaccineMasterService vaccineMasterService;

    @GetMapping("/list")
    public String listVaccines(Model model) {
        List<VaccineMaster> vaccines = vaccineMasterService.getAllVaccines();
        model.addAttribute("vaccines", vaccines);
        return "vaccine-master-list";
    }

    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("vaccine", new VaccineMaster());
        return "vaccine-master-form";
    }

    @PostMapping("/save")
    public String saveVaccine(@RequestParam(required = false) UUID id,
                             @RequestParam String vaccineName,
                             @RequestParam Integer maxDoses,
                             @RequestParam Integer intervalValue,
                             @RequestParam String intervalUnit,
                             @RequestParam(defaultValue = "true") Boolean active,
                             Model model) {
        try {
            VaccineMaster vaccine = new VaccineMaster();
            vaccine.setId(id);
            vaccine.setVaccineName(vaccineName);
            vaccine.setMaxDoses(maxDoses);
            vaccine.setIntervalValue(intervalValue);
            vaccine.setIntervalUnit(intervalUnit);
            vaccine.setActive(active);

            if (id != null) {
                vaccineMasterService.updateVaccine(id, vaccine);
            } else {
                vaccineMasterService.saveVaccine(vaccine);
            }

            return "redirect:/vaccine-master-ui/list";
        } catch (Exception e) {
            model.addAttribute("errorMessage", e.getMessage());
            model.addAttribute("vaccine", new VaccineMaster());
            return "vaccine-master-form";
        }
    }

    @GetMapping("/{id}")
    public String viewVaccine(@PathVariable UUID id, Model model) {
        VaccineMaster vaccine = vaccineMasterService.getVaccineById(id);
        model.addAttribute("vaccine", vaccine);
        return "vaccine-master-details";
    }

    @GetMapping("/{id}/edit")
    public String showEditForm(@PathVariable UUID id, Model model) {
        VaccineMaster vaccine = vaccineMasterService.getVaccineById(id);
        model.addAttribute("vaccine", vaccine);
        return "vaccine-master-form";
    }

    @GetMapping("/{id}/delete")
    public String deleteVaccine(@PathVariable UUID id) {
        vaccineMasterService.deleteVaccine(id);
        return "redirect:/vaccine-master-ui/list";
    }
}
