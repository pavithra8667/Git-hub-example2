package com.infinite.ehrSystem.labResults.controller;

import java.time.LocalDate;
import java.util.UUID;

import com.infinite.ehrSystem.exception.DuplicateLabResultException;
import com.infinite.ehrSystem.exception.InvalidLabOrderStateException;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.infinite.ehrSystem.labResults.dto.LabResultDTO;
import com.infinite.ehrSystem.labResults.service.LabResultService;

import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/lab-results")
@RequiredArgsConstructor
public class LabResultPageController {
    private final LabResultService labResultService;

    @GetMapping("/new")
    @PreAuthorize("hasRole('LAB_TECH')")
    public String newResult(@RequestParam UUID labOrderId, Model model) {
        model.addAttribute("labOrderId", labOrderId);
        model.addAttribute("today", LocalDate.now());
        return "labResult/lab-result-form";
    }

    @PostMapping("/save")
    @PreAuthorize("hasRole('LAB_TECH')")
    public String saveLabResult(
            @RequestParam UUID labOrderId,
            @RequestParam String resultValue,
            @RequestParam(required = false) String unit,
            @RequestParam String referenceRange,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate resultDate,
            Model model) {

        LabResultDTO dto = new LabResultDTO();

        dto.setLabOrderId(labOrderId);
        dto.setResultValue(resultValue);
        dto.setUnit(unit);
        dto.setReferenceRange(referenceRange);
        dto.setResultDate(resultDate);

        try {

            labResultService.createLabResult(dto);

            return "redirect:/dashboard";

        } catch (InvalidLabOrderStateException | DuplicateLabResultException e) {

            model.addAttribute("errorMessage", e.getMessage());

            // Keep the entered values
            model.addAttribute("labOrderId", labOrderId);
            model.addAttribute("resultValue", resultValue);
            model.addAttribute("unit", unit);
            model.addAttribute("referenceRange", referenceRange);
            model.addAttribute("resultDate", resultDate);

            return "labResult/lab-result-form";
        }
    }

    @GetMapping("/view/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','LAB_TECH','PATIENT')")
    public String viewResult(@PathVariable UUID id, Model model) {
        model.addAttribute("result", labResultService.getLabResultById(id));
        return "labResult/lab-result-view";
    }

    @GetMapping("/by-order")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','LAB_TECH')")
    public String viewResultByOrder(@RequestParam UUID labOrderId) {
        try {
            com.infinite.ehrSystem.labResults.dto.LabResultDTO dto = labResultService.getLabResultByLabOrderId(labOrderId);
            return "redirect:/lab-results/view/" + dto.getId();
        } catch (Exception e) {
            return "redirect:/dashboard";
        }
    }
}
