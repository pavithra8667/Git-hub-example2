package com.infinite.ehrSystem.labResults.service;

import com.infinite.ehrSystem.exception.LabOrderNotFoundException;
import com.infinite.ehrSystem.labResults.dto.LabOrderDTO;
import com.infinite.ehrSystem.labResults.entity.LabOrder;
import com.infinite.ehrSystem.labResults.entity.LabOrderStatus;
import com.infinite.ehrSystem.labResults.repository.LabOrderRepository;
import com.infinite.ehrSystem.labResults.mapper.LabOrderMapper;
import com.infinite.ehrSystem.patient.repository.PatientRepository;
import com.infinite.ehrSystem.patient.entity.Patient;
import com.infinite.ehrSystem.visit.repository.VisitRepository;
import com.infinite.ehrSystem.visit.entity.Visit;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class LabOrderServiceImpl implements LabOrderService {

    private static final Logger logger = LogManager.getLogger(LabOrderServiceImpl.class);

    private final LabOrderRepository labOrderRepository;
    private final LabOrderMapper labOrderMapper;
    private final VisitRepository visitRepository;
    private final PatientRepository patientRepository;

    public LabOrderServiceImpl(
            LabOrderRepository labOrderRepository,
            LabOrderMapper labOrderMapper,
            VisitRepository visitRepository,
            PatientRepository patientRepository) {

        this.labOrderRepository = labOrderRepository;
        this.labOrderMapper = labOrderMapper;
        this.visitRepository = visitRepository;
        this.patientRepository = patientRepository;
    }

    @Override
    public LabOrderDTO createLabOrder(LabOrderDTO dto) {
        logger.info("Creating lab order");

        LabOrder labOrder = labOrderMapper.toEntity(dto);
        labOrder.setId(null);
        if (labOrder.getStatus() == null) {
            labOrder.setStatus(LabOrderStatus.ORDERED);
        }

        LabOrder savedOrder =
                labOrderRepository.save(labOrder);

        return labOrderMapper.toDTO(savedOrder);
    }

    @Override
    @Transactional(readOnly = true)
    public LabOrderDTO getLabOrderById(UUID id) {
        logger.debug("Loading lab order");

        LabOrder labOrder =
                labOrderRepository.findById(id).orElseThrow(() ->
                                new LabOrderNotFoundException("Lab order not found with id: " + id));
        return labOrderMapper.toDTO(labOrder);
    }

    @Override
    @Transactional(readOnly = true)
    public List<LabOrderDTO> getLabOrdersByVisitId(UUID visitId) {
        return labOrderRepository
                .findByVisitId(visitId)
                .stream()
                .map(labOrderMapper::toDTO)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<LabOrderDTO> getAllLabOrders() {
        List<LabOrderDTO> all = labOrderRepository
                .findAll()
                .stream()
                .map(labOrderMapper::toDTO)
                .toList();

        // Enrich with patient information and patient name
        for (LabOrderDTO dto : all) {
            if (dto.getVisitId() != null) {
                visitRepository.findById(dto.getVisitId()).ifPresent((Visit visit) -> {
                    dto.setPatientId(visit.getPatientId());
                    patientRepository.findById(visit.getPatientId()).ifPresent((Patient patient) -> dto.setPatientName(patient.getName()));
                });
            }
        }

        // Move ORDERED to top
        List<LabOrderDTO> ordered = all.stream().filter(o -> o.getStatus() == LabOrderStatus.ORDERED).toList();
        List<LabOrderDTO> others = all.stream().filter(o -> o.getStatus() != LabOrderStatus.ORDERED).toList();
        List<LabOrderDTO> result = new java.util.ArrayList<>();
        result.addAll(ordered);
        result.addAll(others);
        return result;
    }

    @Override
    @Transactional(readOnly = true)
    public List<LabOrderDTO> getLabOrdersByVisitIdAndStatus(UUID visitId, LabOrderStatus status) {
        return labOrderRepository
                .findByVisitIdAndStatus(visitId, status)
                .stream()
                .map(labOrderMapper::toDTO)
                .toList();
    }



    @Override
    public LabOrderDTO updateLabOrder(UUID id, LabOrderDTO dto) {
        logger.info("Updating lab order");
        LabOrder labOrder = labOrderRepository.findById(id).orElseThrow(() ->
                        new LabOrderNotFoundException("Lab order not found with id: " + id));
        LabOrder mappedLabOrder = labOrderMapper.toEntity(dto);
        labOrder.setVisitId(mappedLabOrder.getVisitId());
        labOrder.setTestName(mappedLabOrder.getTestName());

        if (mappedLabOrder.getStatus() != null)
        {
            labOrder.setStatus(mappedLabOrder.getStatus());
        }

        LabOrder updatedOrder =
                labOrderRepository.save(labOrder);

        return labOrderMapper.toDTO(updatedOrder);
    }

    @Override
    public void deleteLabOrder(UUID id) {
        logger.info("Deleting lab order");

        if (!labOrderRepository.existsById(id)) {
            throw new LabOrderNotFoundException(
                    "Lab order not found with id: " + id
            );
        }

        labOrderRepository.deleteById(id);
    }
}
