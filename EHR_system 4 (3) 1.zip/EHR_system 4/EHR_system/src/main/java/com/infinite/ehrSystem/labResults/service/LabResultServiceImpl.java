package com.infinite.ehrSystem.labResults.service;
import com.infinite.ehrSystem.exception.DuplicateLabResultException;
import com.infinite.ehrSystem.exception.InvalidLabOrderStateException;
import com.infinite.ehrSystem.exception.LabOrderNotFoundException;
import com.infinite.ehrSystem.exception.LabResultNotFoundException;
import com.infinite.ehrSystem.labResults.dto.LabResultDTO;
import com.infinite.ehrSystem.labResults.entity.LabOrder;
import com.infinite.ehrSystem.labResults.entity.LabOrderStatus;
import com.infinite.ehrSystem.labResults.entity.LabResult;
import com.infinite.ehrSystem.labResults.entity.ResultFlag;
import com.infinite.ehrSystem.labResults.repository.LabOrderRepository;
import com.infinite.ehrSystem.labResults.repository.LabResultRepository;
import com.infinite.ehrSystem.labResults.mapper.LabResultMapper;
import com.infinite.ehrSystem.labResults.strategy.ResultFlagStrategy;
import com.infinite.ehrSystem.labResults.strategy.ResultFlagStrategyFactory;
import com.infinite.ehrSystem.labResults.strategy.ResultType;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.UUID;

@Service
@Transactional
public class LabResultServiceImpl implements LabResultService {

    private static final Logger logger = LogManager.getLogger(LabResultServiceImpl.class);

    private final LabResultRepository labResultRepository;
    private final LabOrderRepository labOrderRepository;
    private final ResultFlagStrategyFactory resultFlagStrategyFactory;
    private final LabResultMapper labResultMapper;

    public LabResultServiceImpl(
            LabResultRepository labResultRepository,
            LabOrderRepository labOrderRepository,
            ResultFlagStrategyFactory resultFlagStrategyFactory,
            LabResultMapper labResultMapper) {

        this.labResultRepository = labResultRepository;
        this.labOrderRepository = labOrderRepository;
        this.resultFlagStrategyFactory = resultFlagStrategyFactory;
        this.labResultMapper = labResultMapper;
    }
    @Override
    public LabResultDTO createLabResult(LabResultDTO dto)
    {
        logger.info("Creating lab result");
        // Ensure lab order exists
        LabOrder labOrder = getLabOrder(dto.getLabOrderId());

        if (labOrder.getStatus()
                != LabOrderStatus.ORDERED)
        {
            throw new InvalidLabOrderStateException(
                    "Lab result can only be entered for ORDERED lab orders"
            );
        }
        // Prevent duplicate lab result
        if (labResultRepository.existsByLabOrderId(dto.getLabOrderId()))
        {
            throw new DuplicateLabResultException("Lab result already exists for lab order: " + dto.getLabOrderId());
        }

        // Calculate NORMAL / ABNORMAL
        ResultFlag flag = calculateFlag(dto.getResultValue(), dto.getReferenceRange());

        LabResult labResult = labResultMapper.toEntity(dto);
        labResult.setId(null);
        labResult.setFlag(flag);

        LabResult savedResult = labResultRepository.save(labResult);

        // Mark order completed
        labOrder.setStatus(LabOrderStatus.COMPLETED);

        labOrderRepository.save(labOrder);

        return labResultMapper.toDTO(savedResult, labOrder);
    }

    @Override
    @Transactional(readOnly = true)
    public LabResultDTO getLabResultById(UUID id)
    {
        logger.debug("Loading lab result");
        LabResult labResult = getLabResult(id);
        LabOrder labOrder = getLabOrder(labResult.getLabOrderId());
        return labResultMapper.toDTO(labResult, labOrder);
    }

    @Override
    public LabResultDTO getLabResultByLabOrderId(UUID labOrderId)
    {
        LabResult labResult = labResultRepository.findByLabOrderId(labOrderId).orElseThrow(() ->
                                new LabResultNotFoundException("Lab result not found for lab order: " + labOrderId));
        LabOrder labOrder = getLabOrder(labOrderId);
        return labResultMapper.toDTO(labResult, labOrder);
    }

    @Override
    public LabResultDTO updateLabResult(UUID id, LabResultDTO dto)
    {
        logger.info("Updating lab result");
        LabResult labResult = getLabResult(id);
        LabOrder labOrder = getLabOrder(labResult.getLabOrderId());

        LabResult mappedResult = labResultMapper.toEntity(dto);
        ResultFlag flag = calculateFlag(mappedResult.getResultValue(), mappedResult.getReferenceRange());
            labResult.setResultValue(mappedResult.getResultValue());
            labResult.setUnit(mappedResult.getUnit());
            labResult.setReferenceRange(mappedResult.getReferenceRange());
            labResult.setFlag(flag);
            labResult.setResultDate(mappedResult.getResultDate());

        LabResult updatedResult = labResultRepository.save(labResult);

        return labResultMapper.toDTO(updatedResult, labOrder);
    }

    @Override
    public void deleteLabResult(UUID id)
    {
        logger.info("Deleting lab result");
        if (!labResultRepository.existsById(id))
        {
            throw new LabResultNotFoundException("Lab result not found with id: " + id);
        }
        labResultRepository.deleteById(id);
    }

    private LabOrder getLabOrder(UUID id)
    {
        return labOrderRepository.findById(id).orElseThrow(() ->
                        new LabOrderNotFoundException("Lab order not found with id: " + id));
    }

    private LabResult getLabResult(UUID id)
    {
        return labResultRepository.findById(id).orElseThrow(() ->
                        new LabResultNotFoundException("Lab result not found with id: "+ id));
    }

    private ResultFlag calculateFlag(String resultValue, String referenceRange)
    {
        ResultType resultType = determineResultType(resultValue);
        ResultFlagStrategy strategy = resultFlagStrategyFactory.getStrategy(resultType);

        return strategy.calculateFlag(resultValue, referenceRange);
    }

    private ResultType determineResultType(String resultValue)
    {
        String value = resultValue.trim();
        if ("POSITIVE".equalsIgnoreCase(value) || "NEGATIVE".equalsIgnoreCase(value))
        {
            return ResultType.POSITIVE_NEGATIVE;
        }
        return ResultType.NUMERIC;
    }

}
