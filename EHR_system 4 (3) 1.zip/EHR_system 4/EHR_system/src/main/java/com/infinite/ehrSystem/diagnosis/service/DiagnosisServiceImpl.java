package com.infinite.ehrSystem.diagnosis.service;
import com.infinite.ehrSystem.allergy.dto.AllergyDTO;
import com.infinite.ehrSystem.allergy.service.AllergyService;
import com.infinite.ehrSystem.diagnosis.dto.DiagnosisDTO;
import com.infinite.ehrSystem.diagnosis.entity.Diagnosis;
import com.infinite.ehrSystem.diagnosis.entity.DiagnosisType;
import com.infinite.ehrSystem.diagnosis.repository.DiagnosisRepository;
import com.infinite.ehrSystem.diagnosis.mapper.DiagnosisMapper;
import com.infinite.ehrSystem.visit.entity.Visit;
import com.infinite.ehrSystem.visit.entity.VisitStatus;
import com.infinite.ehrSystem.visit.repository.VisitRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class DiagnosisServiceImpl implements DiagnosisService {
    private static final Logger logger = LogManager.getLogger(DiagnosisServiceImpl.class);
    private final DiagnosisRepository diagnosisRepository;
    private final VisitRepository visitRepository;
    private final DiagnosisMapper diagnosisMapper;
    private final AllergyService allergyService;

    @Override
    @Transactional
    public DiagnosisDTO createDiagnosis(UUID visitId, DiagnosisDTO diagnosisDTO) {
        logger.info("Creating diagnosis");
        Visit visit = visitRepository.findById(visitId)
                .orElseThrow(() -> new IllegalStateException("Visit not found with id: " + visitId));

        if (visit.getStatus() != VisitStatus.OPEN) {
            throw new IllegalStateException("Diagnosis can only be created for an OPEN visit");
        }
        if (diagnosisDTO.getDiagnosisType() == DiagnosisType.PRIMARY) {
            boolean primaryExists = diagnosisRepository.existsByVisitIdAndDiagnosisType(visitId, DiagnosisType.PRIMARY);
            if (primaryExists) {
                throw new IllegalStateException("A PRIMARY diagnosis already exists for this visit");
            }
        }

        Diagnosis diagnosis = diagnosisMapper.toEntity(diagnosisDTO);
        diagnosis.setId(null);
        diagnosis.setVisitId(visitId);

        if (diagnosis.getDiagnosisCode() == null || diagnosis.getDiagnosisCode().isBlank()) {
            throw new IllegalStateException("Diagnosis code is required");
        }

        diagnosis.setDiagnosisCode(diagnosis.getDiagnosisCode().trim().toUpperCase());
        diagnosis.setDescription(diagnosisDTO.getDescription().trim());
        Diagnosis savedDiagnosis = diagnosisRepository.save(diagnosis);
        return diagnosisMapper.toDTO(savedDiagnosis);
    }

    private String generateDiagnosisCode(UUID visitId) {
        List<Diagnosis> diagnoses = diagnosisRepository.findByVisitId(visitId);
        int nextIndex = diagnoses.size() + 1;
        return "DC-" + nextIndex;
    }

    @Override
    @Transactional(readOnly = true)
    public DiagnosisDTO getDiagnosisById(UUID id) {
        logger.debug("Loading diagnosis");
        Diagnosis diagnosis = diagnosisRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("Diagnosis not found with id: " + id));
        return diagnosisMapper.toDTO(diagnosis);
    }
    @Override
    @Transactional(readOnly = true)
    public List<AllergyDTO> getPatientAllergies(UUID visitId) {

        Visit visit = visitRepository.findById(visitId)
                .orElseThrow(() ->
                        new EntityNotFoundException(
                                "Visit not found with id: "
                                        + visitId));

        return allergyService.getAllergies(
                visit.getPatientId()
        );

    }
    @Override
    @Transactional(readOnly = true)
    public List<DiagnosisDTO> getDiagnosesByVisit(UUID visitId) {
        if (!visitRepository.existsById(visitId)) {throw new EntityNotFoundException("Visit not found with id: " + visitId);
        }
        return diagnosisRepository
                .findByVisitId(visitId)
                .stream()
                .map(diagnosisMapper::toDTO)
                .toList();
    }
    @Override
    @Transactional
    public void deleteDiagnosis(UUID id) {
        logger.info("Deleting diagnosis");
        Diagnosis diagnosis = diagnosisRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("Diagnosis not found with id: " + id));
        diagnosisRepository.delete(diagnosis);
    }
}
