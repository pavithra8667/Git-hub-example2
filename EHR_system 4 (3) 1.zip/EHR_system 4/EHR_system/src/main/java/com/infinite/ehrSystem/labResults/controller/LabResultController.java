package com.infinite.ehrSystem.labResults.controller;

import com.infinite.ehrSystem.labResults.dto.LabResultDTO;
import com.infinite.ehrSystem.labResults.service.LabResultService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import lombok.extern.log4j.Log4j2;

import java.util.UUID;

@RestController
@Log4j2
@RequestMapping("/api/lab-results")
public class LabResultController {

    private final LabResultService labResultService;

    public LabResultController(LabResultService labResultService) {
        this.labResultService = labResultService;
    }

    @PreAuthorize("hasRole('LAB_TECH')")
    @PostMapping
    public ResponseEntity<LabResultDTO> createLabResult(@Valid @RequestBody LabResultDTO dto) {
        log.info("Creating lab result");
        LabResultDTO createdResult = labResultService.createLabResult(dto);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(createdResult);
    }

    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','LAB_TECH','PATIENT')")
    @GetMapping("/{id}")
    public ResponseEntity<LabResultDTO> getLabResultById(@PathVariable UUID id) {
        log.debug("Fetching lab result");
        return ResponseEntity.ok(labResultService.getLabResultById(id));
    }

    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','LAB_TECH','PATIENT')")
    @GetMapping("/lab-order/{labOrderId}")
    public ResponseEntity<LabResultDTO>
    getLabResultByLabOrderId(@PathVariable UUID labOrderId) {
        log.debug("Fetching lab result by lab order");
        return ResponseEntity.ok(labResultService.getLabResultByLabOrderId(labOrderId));
    }

    @PreAuthorize("denyAll()")
    @PutMapping("/{id}")
    public ResponseEntity<LabResultDTO> updateLabResult(
            @PathVariable UUID id, @Valid @RequestBody LabResultDTO dto) {
        log.info("Updating lab result");
        return ResponseEntity.ok(labResultService.updateLabResult(id, dto));
    }

    @PreAuthorize("denyAll()")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLabResult(@PathVariable UUID id) {
        log.info("Deleting lab result");
        labResultService.deleteLabResult(id);
        return ResponseEntity.noContent().build();
    }
}
