package com.infinite.ehrSystem.doctorNote.service;

import com.infinite.ehrSystem.doctorNote.dto.DoctorNoteDTO;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface DoctorNoteService {

    DoctorNoteDTO saveDoctorNote(DoctorNoteDTO doctorNoteDTO);

    List<DoctorNoteDTO> getNotesByVisitId(UUID visitId);

    DoctorNoteDTO getDoctorNoteById(UUID id);

    UUID getDoctorIdForVisit(UUID visitId);

    List<DoctorNoteDTO> getNotesByPatientId(UUID patientId);

    Map<String, Object> getVisitDetailsForView(UUID visitId, UUID doctorId);

    Map<String, Object> getVisitDetailsForForm(UUID visitId, UUID doctorId);
}