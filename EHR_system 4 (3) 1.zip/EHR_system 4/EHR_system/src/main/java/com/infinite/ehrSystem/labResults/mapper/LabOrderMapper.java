package com.infinite.ehrSystem.labResults.mapper;

import com.infinite.ehrSystem.labResults.dto.LabOrderDTO;
import com.infinite.ehrSystem.labResults.entity.LabOrder;
import org.springframework.stereotype.Component;

@Component
public class LabOrderMapper {

    public LabOrderDTO toDTO(LabOrder labOrder) {
        if (labOrder == null) {
            return null;
        }

        return LabOrderDTO.builder()
                .id(labOrder.getId())
                .visitId(labOrder.getVisitId())
                .testName(labOrder.getTestName())
                .status(labOrder.getStatus())
                .build();
    }

    public LabOrder toEntity(LabOrderDTO dto) {
        if (dto == null) {
            return null;
        }

        return LabOrder.builder()
                .id(dto.getId())
                .visitId(dto.getVisitId())
                .testName(dto.getTestName())
                .status(dto.getStatus())
                .build();
    }
}
