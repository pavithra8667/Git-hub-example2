package com.infinite.ehrSystem.diagnosis.mapper;

import com.infinite.ehrSystem.diagnosis.dto.DiagnosisDTO;
import com.infinite.ehrSystem.diagnosis.entity.Diagnosis;
import org.springframework.stereotype.Component;

@Component
public class DiagnosisMapper {

    public DiagnosisDTO toDTO(Diagnosis diagnosis) {
        if (diagnosis == null) {
            return null;
        }

        return DiagnosisDTO.builder()
                .id(diagnosis.getId())
                .visitId(diagnosis.getVisitId())
                .diagnosisCode(diagnosis.getDiagnosisCode())
                .description(diagnosis.getDescription())
                .diagnosisType(diagnosis.getDiagnosisType())
                .build();
    }

    public Diagnosis toEntity(DiagnosisDTO dto) {
        if (dto == null) {
            return null;
        }

        return Diagnosis.builder()
                .id(dto.getId())
                .visitId(dto.getVisitId())
                .diagnosisCode(dto.getDiagnosisCode())
                .description(dto.getDescription())
                .diagnosisType(dto.getDiagnosisType())
                .build();
    }
}
