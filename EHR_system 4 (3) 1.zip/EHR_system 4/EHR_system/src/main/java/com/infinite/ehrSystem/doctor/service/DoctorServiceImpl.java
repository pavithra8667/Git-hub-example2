package com.infinite.ehrSystem.doctor.service;

import com.infinite.ehrSystem.auth.repository.UserRepository;
import com.infinite.ehrSystem.doctor.dto.DoctorDTO;
import com.infinite.ehrSystem.doctor.entity.Doctor;
import com.infinite.ehrSystem.doctor.repository.DoctorRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class DoctorServiceImpl implements DoctorService {

    private final DoctorRepository doctorRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional
    public DoctorDTO createDoctor(DoctorDTO doctorDTO) {

        if (doctorDTO.getUserId() == null) {
            throw new IllegalArgumentException("User ID is required");
        }

        // Verify user exists
        var user = userRepository.findById(doctorDTO.getUserId())
                .orElseThrow(() -> new EntityNotFoundException(
                        "User not found with id: " + doctorDTO.getUserId()));

        // Check if license number already exists
        if (doctorRepository.findByLicenseNumber(doctorDTO.getLicenseNumber()).isPresent()) {
            throw new IllegalArgumentException(
                    "Doctor with license number " + doctorDTO.getLicenseNumber() + " already exists");
        }

        Doctor doctor = new Doctor();
        doctor.setUserId(doctorDTO.getUserId());
        doctor.setSpecialization(doctorDTO.getSpecialization());
        doctor.setQualification(doctorDTO.getQualification());
        doctor.setLicenseNumber(doctorDTO.getLicenseNumber());
        doctor.setYearsOfExperience(doctorDTO.getYearsOfExperience());
        doctor.setPhone(doctorDTO.getPhone());
        doctor.setAddress(doctorDTO.getAddress());
        doctor.setClinicName(doctorDTO.getClinicName());
        doctor.setIsAvailable(doctorDTO.getIsAvailable() != null ? doctorDTO.getIsAvailable() : true);
        doctor.setConsultationFee(doctorDTO.getConsultationFee());

        Doctor savedDoctor = doctorRepository.save(doctor);
        return convertToDTO(savedDoctor, user.getUsername(), user.getEmail());
    }

    @Override
    @Transactional(readOnly = true)
    public DoctorDTO getDoctorById(UUID id) {
        Doctor doctor = doctorRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Doctor not found with id: " + id));
        
        var user = userRepository.findById(doctor.getUserId())
                .orElseThrow(() -> new EntityNotFoundException("User not found"));
        
        return convertToDTO(doctor, user.getUsername(), user.getEmail());
    }

    @Override
    @Transactional(readOnly = true)
    public DoctorDTO getDoctorByUserId(UUID userId) {
        Doctor doctor = doctorRepository.findByUserId(userId)
                .orElseThrow(() -> new EntityNotFoundException("Doctor not found for user id: " + userId));
        
        var user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found"));
        
        return convertToDTO(doctor, user.getUsername(), user.getEmail());
    }

    @Override
    @Transactional(readOnly = true)
    public List<DoctorDTO> getAllDoctors() {
        return doctorRepository.findAll()
                .stream()
                .map(doctor -> {
                    var user = userRepository.findById(doctor.getUserId()).orElse(null);
                    return convertToDTO(doctor, 
                            user != null ? user.getUsername() : "Unknown",
                            user != null ? user.getEmail() : "");
                })
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<DoctorDTO> getDoctorsBySpecialization(String specialization) {
        return doctorRepository.findBySpecialization(specialization)
                .stream()
                .map(doctor -> {
                    var user = userRepository.findById(doctor.getUserId()).orElse(null);
                    return convertToDTO(doctor,
                            user != null ? user.getUsername() : "Unknown",
                            user != null ? user.getEmail() : "");
                })
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<DoctorDTO> getAvailableDoctors() {
        return doctorRepository.findByIsAvailableTrue()
                .stream()
                .map(doctor -> {
                    var user = userRepository.findById(doctor.getUserId()).orElse(null);
                    return convertToDTO(doctor,
                            user != null ? user.getUsername() : "Unknown",
                            user != null ? user.getEmail() : "");
                })
                .toList();
    }

    @Override
    @Transactional
    public DoctorDTO updateDoctor(UUID id, DoctorDTO doctorDTO) {
        Doctor doctor = doctorRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Doctor not found with id: " + id));

        if (doctorDTO.getSpecialization() != null) {
            doctor.setSpecialization(doctorDTO.getSpecialization());
        }
        if (doctorDTO.getQualification() != null) {
            doctor.setQualification(doctorDTO.getQualification());
        }
        if (doctorDTO.getYearsOfExperience() != null) {
            doctor.setYearsOfExperience(doctorDTO.getYearsOfExperience());
        }
        if (doctorDTO.getPhone() != null) {
            doctor.setPhone(doctorDTO.getPhone());
        }
        if (doctorDTO.getAddress() != null) {
            doctor.setAddress(doctorDTO.getAddress());
        }
        if (doctorDTO.getClinicName() != null) {
            doctor.setClinicName(doctorDTO.getClinicName());
        }
        if (doctorDTO.getIsAvailable() != null) {
            doctor.setIsAvailable(doctorDTO.getIsAvailable());
        }
        if (doctorDTO.getConsultationFee() != null) {
            doctor.setConsultationFee(doctorDTO.getConsultationFee());
        }

        Doctor updatedDoctor = doctorRepository.save(doctor);
        var user = userRepository.findById(doctor.getUserId()).orElse(null);
        
        return convertToDTO(updatedDoctor,
                user != null ? user.getUsername() : "Unknown",
                user != null ? user.getEmail() : "");
    }

    @Override
    @Transactional
    public void deleteDoctor(UUID id) {
        Doctor doctor = doctorRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Doctor not found with id: " + id));
        doctorRepository.delete(doctor);
    }

    private DoctorDTO convertToDTO(Doctor doctor, String username, String email) {
        DoctorDTO dto = new DoctorDTO();
        dto.setId(doctor.getId());
        dto.setUserId(doctor.getUserId());
        dto.setSpecialization(doctor.getSpecialization());
        dto.setQualification(doctor.getQualification());
        dto.setLicenseNumber(doctor.getLicenseNumber());
        dto.setYearsOfExperience(doctor.getYearsOfExperience());
        dto.setPhone(doctor.getPhone());
        dto.setAddress(doctor.getAddress());
        dto.setClinicName(doctor.getClinicName());
        dto.setIsAvailable(doctor.getIsAvailable());
        dto.setConsultationFee(doctor.getConsultationFee());
        dto.setUsername(username);
        dto.setEmail(email);
        dto.setCreatedBy(doctor.getCreatedBy());
        dto.setCreatedOn(doctor.getCreatedOn());
        dto.setUpdatedBy(doctor.getUpdatedBy());
        dto.setUpdatedOn(doctor.getUpdatedOn());
        return dto;
    }
}
