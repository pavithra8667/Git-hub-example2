-- Schema fixes applied by automated patch: ensure audit columns exist on `visits` table
-- Safe: uses IF NOT EXISTS so it can be run multiple times on MySQL 8+

ALTER TABLE `visits`
  ADD COLUMN IF NOT EXISTS `created_by` VARCHAR(255) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `created_on` DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
  ADD COLUMN IF NOT EXISTS `updated_by` VARCHAR(255) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `updated_on` DATETIME DEFAULT NULL;

-- End of schema.sql
