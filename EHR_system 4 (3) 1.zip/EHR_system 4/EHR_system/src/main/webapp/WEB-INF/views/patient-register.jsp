<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Patient Registration</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            max-width: 600px;
            width: 100%;
            padding: 40px;
        }

        h1 {
            color: #333;
            margin-bottom: 30px;
            text-align: center;
            font-size: 28px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }

        input[type="text"],
        input[type="date"],
        input[type="tel"],
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            font-family: inherit;
            transition: border-color 0.3s;
        }

        input[type="text"]:focus,
        input[type="date"]:focus,
        input[type="tel"]:focus,
        select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 5px rgba(102, 126, 234, 0.1);
        }

        .required::after {
            content: " *";
            color: red;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-row.full {
            grid-template-columns: 1fr;
        }

        .error-message {
            color: #e74c3c;
            font-size: 12px;
            margin-top: 5px;
            display: none;
        }

        .button-group {
            display: flex;
            gap: 10px;
            justify-content: center;
            margin-top: 30px;
        }

        button {
            padding: 12px 30px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
        }

        button[type="submit"] {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            min-width: 150px;
        }

        button[type="submit"]:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }

        button[type="reset"] {
            background: #ecf0f1;
            color: #333;
            min-width: 150px;
        }

        button[type="reset"]:hover {
            background: #bdc3c7;
        }

        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 20px;
            display: none;
        }

        .error-box {
            background: #f8d7da;
            color: #721c24;
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 20px;
            display: none;
        }

        .info-text {
            font-size: 12px;
            color: #7f8c8d;
            margin-top: 4px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Patient Registration</h1>

        <div class="success-message" id="successMessage">
            Patient registered successfully!
        </div>

        <div class="error-box" id="errorMessage">
            <!-- Error messages will be displayed here -->
        </div>

        <form id="patientForm" onsubmit="registerPatient(event)">
            <!-- Name -->
            <div class="form-group">
                <label for="name" class="required">Full Name</label>
                <input type="text" id="name" name="name"
                       placeholder="Enter patient's full name"
                       minlength="3" maxlength="80" required>
                <div class="error-message" id="nameError"></div>
                <div class="info-text">3-80 characters</div>
            </div>

            <!-- DOB and Gender -->
            <div class="form-row">
                <div class="form-group">
                    <label for="dob" class="required">Date of Birth</label>
                    <input type="date" id="dob" name="dob" required>
                    <div class="error-message" id="dobError"></div>
                </div>

                <div class="form-group">
                    <label for="gender">Gender</label>
                    <select id="gender" name="gender">
                        <option value="">-- Select Gender --</option>
                        <option value="MALE">Male</option>
                        <option value="FEMALE">Female</option>
                        <option value="OTHER">Other</option>
                    </select>
                </div>
            </div>

            <!-- Phone and Blood Group -->
            <div class="form-row">
                <div class="form-group">
                    <label for="phone" class="required">Phone Number</label>
                    <input type="tel" id="phone" name="phone"
                           placeholder="10 digit number"
                           pattern="\d{10}" maxlength="10" required>
                    <div class="error-message" id="phoneError"></div>
                    <div class="info-text">Exactly 10 digits</div>
                </div>

                <div class="form-group">
                    <label for="bloodGroup">Blood Group</label>
                    <select id="bloodGroup" name="bloodGroup">
                        <option value="">-- Select Blood Group --</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                    </select>
                </div>
            </div>

            <!-- Guardian Name -->
            <div class="form-group form-row full">
                <label for="guardianName">Guardian Name</label>
                <input type="text" id="guardianName" name="guardianName"
                       placeholder="Enter guardian's name (if applicable)"
                       maxlength="100">
                <div class="info-text">Optional - for minors or dependent adults</div>
            </div>

            <!-- Buttons -->
            <div class="button-group">
                <button type="submit">Register Patient</button>
                <button type="reset">Clear Form</button>
            </div>
        </form>
    </div>

    <script>
        function registerPatient(event) {
            event.preventDefault();

            // Clear previous error messages
            document.getElementById('errorMessage').style.display = 'none';
            document.getElementById('successMessage').style.display = 'none';
            clearErrorMessages();

            // Get form data
            const formData = {
                name: document.getElementById('name').value,
                dob: document.getElementById('dob').value,
                gender: document.getElementById('gender').value || null,
                phone: document.getElementById('phone').value,
                bloodGroup: document.getElementById('bloodGroup').value || null,
                guardianName: document.getElementById('guardianName').value || null
            };

            // Validate DOB is not in the future
            const dobDate = new Date(formData.dob);
            const today = new Date();
            if (dobDate > today) {
                showError('dobError', 'Date of birth cannot be in the future');
                return;
            }

            // Send to API
            fetch('/api/patients/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(error => {
                        throw error;
                    });
                }
                return response.json();
            })
            .then(data => {
                document.getElementById('successMessage').innerHTML =
                    'Patient registered successfully! Patient Code: <strong>' + data.patientCode + '</strong>';
                document.getElementById('successMessage').style.display = 'block';
                document.getElementById('patientForm').reset();

                // Optional: Redirect after 2 seconds
                // setTimeout(() => {
                //     window.location.href = '/dashboard';
                // }, 2000);
            })
            .catch(error => {
                console.error('Error:', error);
                let errorMsg = 'Failed to register patient.';

                if (error.message) {
                    errorMsg += ' ' + error.message;
                }

                document.getElementById('errorMessage').innerHTML = errorMsg;
                document.getElementById('errorMessage').style.display = 'block';
            });
        }

        function showError(elementId, message) {
            const errorElement = document.getElementById(elementId);
            if (errorElement) {
                errorElement.innerHTML = message;
                errorElement.style.display = 'block';
            }
        }

        function clearErrorMessages() {
            const errorElements = document.querySelectorAll('.error-message');
            errorElements.forEach(el => el.style.display = 'none');
        }

        // Real-time phone validation
        document.getElementById('phone').addEventListener('input', function(e) {
            this.value = this.value.replace(/\D/g, '').slice(0, 10);
        });

        // Age calculation on DOB change
        document.getElementById('dob').addEventListener('change', function() {
            const dob = new Date(this.value);
            const today = new Date();
            const age = today.getFullYear() - dob.getFullYear();
            const monthDiff = today.getMonth() - dob.getMonth();

            if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
                age--;
            }

            if (age < 0) {
                showError('dobError', 'Date of birth cannot be in the future');
            } else if (age > 150) {
                showError('dobError', 'Please enter a valid date of birth');
            } else {
                clearErrorMessages();
            }
        });
    </script>
</body>
</html>

