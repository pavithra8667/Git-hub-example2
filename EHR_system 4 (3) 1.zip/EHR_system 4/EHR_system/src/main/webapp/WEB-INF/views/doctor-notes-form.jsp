<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<!DOCTYPE html>
<html>
<head>

    <title>Add Doctor Note</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">

    <style>

        body{

            background:#f4f6f9;
        }

        /* smaller centered card */
        .card{
            max-width:550px; /* target range 500-600px */
            margin:30px auto;
            border-radius:8px;
            box-shadow:0 2px 6px rgba(0,0,0,.12);
            padding:12px !important;
        }

        /* even smaller variant if needed */
        .card.small {
            max-width:520px;
            padding:10px !important;
        }

        /* compact form spacing */
        .mb-3 { margin-bottom:10px !important; }
        label { font-size:14px; }
        input, select, .form-control { font-size:14px; padding:8px; }

        textarea.form-control { height:100px; resize:vertical; }

        /* inline message area */
        #formMessage { margin-bottom:10px; }

        .alert {
            padding:6px 10px;
            margin-bottom:8px;
            border-radius:4px;
            width:100%;
            display:block;
            box-sizing:border-box;
        }

        .alert-success { background-color:#dff0d8; color:#3c763d; border:1px solid #c3e6cb; }
        .alert-danger { background-color:#f2dede; color:#a94442; border:1px solid #ebccd1; }

        .popup-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.38);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        }

        .popup-overlay.show {
            display: flex;
        }

        .popup-box {
            width: 420px;
            max-width: calc(100vw - 30px);
            background: #f3f3f3;
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.18);
            padding: 28px 24px 20px;
        }

        .popup-box h3 {
            margin: 0 0 14px;
            font-size: 28px;
            font-weight: 700;
            color: #1f1f1f;
            text-align: center;
        }

        .popup-box p {
            margin: 0 0 18px;
            font-size: 16px;
            line-height: 1.5;
            color: #555;
        }

        .popup-box button {
            width: 100%;
            background: #4e78ef;
            border: none;
            border-radius: 8px;
            color: white;
            padding: 12px 16px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
        }

        .popup-box button:hover {
            background: #3d67d6;
        }

    </style>

</head>

<body>

<div id="popupOverlay" class="popup-overlay" aria-live="polite">
    <div class="popup-box" role="dialog" aria-modal="true">
        <h3 id="popupTitle">Modal Popup!</h3>
        <p id="popupMessage">Lorem ipsum</p>
        <button type="button" id="popupOkBtn">OK</button>
    </div>
</div>

<div class="container">

<div class="card p-4">

        <h2 class="text-center text-primary mb-4">
            Add Doctor Note
        </h2>

        <form id="doctorNoteForm">



            <div class="mb-3">
                <label class="form-label">Patient Name</label>
                <input type="text"
                       id="patientName"
                       class="form-control"
                       value="${patientName}"
                       readonly>
            </div>

            <div class="mb-3">
                <label class="form-label">Doctor Name</label>
                <input type="text"
                       id="doctorName"
                       class="form-control"
                       value="${doctorName}"
                       readonly>
                <input type="hidden"
                       id="visitId"
                       value="${visitId}">
                <input type="hidden"
                       id="doctorId"
                       value="${doctorId}">
            </div>

            <div class="mb-3">
                <label class="form-label">Note Type</label>

                <select id="noteType"
                        class="form-select">

                    <option value="">Select Note Type</option>

                    <option value="Consultation">
                        Consultation
                    </option>

                    <option value="Observation">
                        Observation
                    </option>

                    <option value="Progress Note">
                        Progress Note
                    </option>

                </select>
            </div>

            <div class="mb-3">

                <label class="form-label">
                    Doctor Note
                </label>

                <textarea id="noteText"
                          class="form-control"
                          rows="4"
                          minlength="10"
                          placeholder="Enter doctor notes here..."></textarea>

            </div>

            <div class="d-flex justify-content-between gap-2">
                <button type="button"
                        onclick="history.back()"
                        class="btn btn-secondary">
                    Back
                </button>

                <button type="button"
                        onclick="saveDoctorNote()"
                        class="btn btn-primary">
                    Save Note
                </button>
            </div>

        </form>

    </div>

</div>

<script>

window.onload = function() {
    const noteTextArea = document.getElementById("noteText");
    if (noteTextArea) {
        noteTextArea.focus();
    }
};

function showPopup(title, message) {
    const overlay = document.getElementById('popupOverlay');
    const titleEl = document.getElementById('popupTitle');
    const messageEl = document.getElementById('popupMessage');
    if (!overlay || !titleEl || !messageEl) return;
    titleEl.textContent = title;
    messageEl.textContent = message;
    overlay.classList.add('show');
}

function closePopup() {
    const overlay = document.getElementById('popupOverlay');
    if (overlay) overlay.classList.remove('show');
}

document.getElementById('popupOkBtn').addEventListener('click', closePopup);

function showFormMessage(type, message) {
    const container = document.getElementById('formMessage');
    if (!container) return;
    container.innerHTML = '';
    const alertDiv = document.createElement('div');
    alertDiv.className = type === 'success' ? 'alert alert-success' : 'alert alert-danger';
    alertDiv.textContent = message;
    container.appendChild(alertDiv);
}

function clearFormMessage() {
    const container = document.getElementById('formMessage');
    if (container) container.innerHTML = '';
}

async function saveDoctorNote() {

clearFormMessage();

const noteTextEl = document.getElementById("noteText");
const noteText = noteTextEl ? noteTextEl.value.trim() : '';
const noteTypeEl = document.getElementById("noteType");
const noteType = noteTypeEl ? noteTypeEl.value : '';

if (!noteType || noteType.trim() === '') {
    showPopup('Error', 'Please select a note type');
    if (noteTypeEl) noteTypeEl.focus();
    return;
}

if (noteText.length < 10) {
    showPopup('Error', 'Minimum 10 characters required');
    if (noteTextEl) noteTextEl.focus();
    return;
}

    const doctorNote = {
        visitId: document.getElementById("visitId").value,
        doctorId: document.getElementById("doctorId").value,
        noteType: noteType,
        noteText: noteText
    };

    try {
        const headers = { 'Content-Type': 'application/json' };
        const csrfHeaderMeta = document.querySelector('meta[name="_csrf_header"]');
        const csrfTokenMeta = document.querySelector('meta[name="_csrf"]');
        if (csrfHeaderMeta && csrfTokenMeta) {
            headers[csrfHeaderMeta.content] = csrfTokenMeta.content;
        }
        try {
            const xsrfCookie = document.cookie.split(';').map(c => c.trim()).find(c => c.startsWith('XSRF-TOKEN='));
            if (xsrfCookie) {
                const token = decodeURIComponent(xsrfCookie.split('=')[1]);
                headers['X-XSRF-TOKEN'] = token;
            }
        } catch (e) {}

        const resp = await fetch("${pageContext.request.contextPath}/doctor-notes/save", {
            method: 'POST',
            headers,
            body: JSON.stringify(doctorNote)
        });

        let data = null;
        try { data = await resp.json(); } catch(e) { /* ignore */ }

        if (!resp.ok) {
            const msg = data && data.message ? data.message : 'Unable to save note';
            showPopup('Error', msg);
            return;
        }

        if (data && data.success) {
            const msg = data.message || 'Doctor note saved successfully';
            showPopup('Success', msg);
            const redirectPath = data.redirect ? data.redirect : ('/doctor-notes/view?visitId=' + doctorNote.visitId);
            const redirectWithMsg = redirectPath + '&message=' + encodeURIComponent(msg);
            setTimeout(function(){
                window.location.href = "${pageContext.request.contextPath}" + redirectWithMsg;
            }, 1000);
        } else {
            showPopup('Error', data && data.message ? data.message : 'Unknown error');
        }

    } catch (err) {
        console.error('Error saving note:', err);
        showPopup('Error', 'Error saving note: ' + (err && err.message ? err.message : 'network error'));
    }
}

</script>

</body>
</html>