<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EHR System | Allergies</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background:#f4f7fb; min-height:100vh; }
        .topbar { background:#0d6efd; }
        .content-card { border:0; border-radius:16px; }
    </style>
</head>
<body>
<nav class="navbar navbar-dark topbar">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold" href="${pageContext.request.contextPath}/dashboard">EHR System</a>
    </div>
</nav>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">Allergies</h2>
            <p class="text-muted mb-0">${patient.name} | ${patient.patientCode}</p>
        </div>
        <div class="d-flex align-items-center gap-2">
            <c:choose>
                <c:when test="${param.source == 'diagnosis'}">
                    <a href="${pageContext.request.contextPath}/diagnoses?visitId=${param.visitId}" class="btn btn-outline-primary btn-sm" style="background-color:#f0f4ff; border-color:#0d6efd; color:#0d6efd; font-weight:600;">Back</a>
                </c:when>
                <c:when test="${param.source == 'prescription'}">
                    <a href="${pageContext.request.contextPath}/prescriptions?visitId=${param.visitId}" class="btn btn-outline-primary btn-sm" style="background-color:#f0f4ff; border-color:#0d6efd; color:#0d6efd; font-weight:600;">Back</a>
                </c:when>
                <c:otherwise>
                    <a href="${pageContext.request.contextPath}/dashboard" class="btn btn-outline-primary btn-sm" style="background-color:#f0f4ff; border-color:#0d6efd; color:#0d6efd; font-weight:600;">Dashboard</a>
                </c:otherwise>
            </c:choose>
            <c:if test="${pageContext.request.isUserInRole('ADMIN') || pageContext.request.isUserInRole('DOCTOR')}">
                <a href="${pageContext.request.contextPath}/patients/${patient.id}/allergies/new" class="btn btn-danger">+ Add Allergy</a>
            </c:if>
        </div>
    </div>

    <c:if test="${not empty successMessage}">
        <div class="alert alert-success">${successMessage}</div>
    </c:if>

    <div class="card content-card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                    <tr>
                        <th class="ps-4">Allergen</th>
                        <th>Reaction</th>
                        <th>Severity</th>
                        <c:if test="${pageContext.request.isUserInRole('ADMIN') || pageContext.request.isUserInRole('DOCTOR')}">
                            <th class="pe-4">Action</th>
                        </c:if>
                    </tr>
                    </thead>
                    <tbody>
                    <c:forEach var="allergy" items="${allergies}">
                        <tr>
                            <td class="ps-4 fw-semibold">${allergy.allergen}</td>
                            <td>${allergy.reaction}</td>
                            <td>
                                <c:choose>
                                    <c:when test="${allergy.severity == 'SEVERE'}"><span class="badge bg-danger">SEVERE</span></c:when>
                                    <c:when test="${allergy.severity == 'MODERATE'}"><span class="badge bg-warning text-dark">MODERATE</span></c:when>
                                    <c:otherwise><span class="badge bg-success">MILD</span></c:otherwise>
                                </c:choose>
                            </td>
                            <c:if test="${pageContext.request.isUserInRole('ADMIN') || pageContext.request.isUserInRole('DOCTOR')}">
                                <td class="pe-4">
                                    <a href="${pageContext.request.contextPath}/patients/${patient.id}/allergies/${allergy.id}/edit" class="btn btn-sm btn-outline-primary">Edit</a>
                                </td>
                            </c:if>
                        </tr>
                    </c:forEach>
                    <c:if test="${empty allergies}">
                        <tr><td colspan="3" class="text-center text-muted py-5">No allergies recorded.</td></tr>
                    </c:if>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
