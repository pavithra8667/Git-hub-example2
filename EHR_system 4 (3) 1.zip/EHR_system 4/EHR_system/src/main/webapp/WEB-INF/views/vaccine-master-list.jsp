<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Vaccine Master</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
        }

        .container {
            width: min(auto, 95vw);
            max-width: 850px;
            margin: 20px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            display: block;
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin: 0 0 12px;
            font-size: 1.6rem;
        }

        .toolbar {
            margin-bottom: 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .toolbar h3 {
            margin: 0;
            color: #555;
            font-size: 14px;
        }

        .add-btn {
            background: #28a745;
            color: white;
            padding: 8px 16px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            font-size: 14px;
        }

        .add-btn:hover {
            background: #218838;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 8px;
            font-size: 14px;
        }

        th {
            background: #007bff;
            color: white;
            padding: 9px 10px;
            border: 1px solid #ddd;
            text-align: left;
            font-weight: bold;
        }

        td {
            padding: 8px 10px;
            border: 1px solid #ddd;
        }

        tr:nth-child(even) {
            background: #f8f9fa;
        }

        .actions {
            display: flex;
            gap: 6px;
        }

        .btn-view, .btn-edit, .btn-delete {
            padding: 5px 10px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 11px;
            font-weight: bold;
            cursor: pointer;
            border: none;
        }

        .btn-view {
            background: #17a2b8;
            color: white;
        }

        .btn-view:hover {
            background: #138496;
        }

        .btn-edit {
            background: #ffc107;
            color: black;
        }

        .btn-edit:hover {
            background: #e0a800;
        }

        .btn-delete {
            background: #dc3545;
            color: white;
        }

        .btn-delete:hover {
            background: #c82333;
        }

        .no-records {
            padding: 15px;
            text-align: center;
            color: #666;
            font-size: 14px;
        }

        .active-badge {
            background: #28a745;
            color: white;
            padding: 3px 6px;
            border-radius: 3px;
            font-size: 11px;
            display: inline-block;
        }

        .inactive-badge {
            background: #6c757d;
            color: white;
            padding: 3px 6px;
            border-radius: 3px;
            font-size: 11px;
            display: inline-block;
        }

        .back-btn {
            margin-top: 12px;
            background: #6c757d;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }

        .back-btn:hover {
            background: #5a6268;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Vaccine Master</h2>

    <div class="toolbar">
        <h3 style="margin: 0; color: #555;">Manage Vaccines</h3>
        <a href="${pageContext.request.contextPath}/vaccine-master-ui/new" class="add-btn">+ Add New Vaccine</a>
    </div>

    <c:choose>
        <c:when test="${not empty vaccines}">
            <table>
                <thead>
                    <tr>
                        <th>Vaccine Name</th>
                        <th>Max Doses</th>
                        <th>Interval Value</th>
                        <th>Interval Unit</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="vaccine" items="${vaccines}">
                        <tr>
                            <td>${vaccine.vaccineName}</td>
                            <td>${vaccine.maxDoses}</td>
                            <td>${vaccine.intervalValue}</td>
                            <td>${vaccine.intervalUnit}</td>
                            <td>
                                <c:choose>
                                    <c:when test="${vaccine.active}">
                                        <span class="active-badge">Active</span>
                                    </c:when>
                                    <c:otherwise>
                                        <span class="inactive-badge">Inactive</span>
                                    </c:otherwise>
                                </c:choose>
                            </td>
                            <td>
                                <div class="actions">

                                    <a href="${pageContext.request.contextPath}/vaccine-master-ui/${vaccine.id}/edit" class="btn-edit">Edit</a>
                                    <a href="${pageContext.request.contextPath}/vaccine-master-ui/${vaccine.id}/delete" class="btn-delete" onclick="return confirm('Are you sure?')">Delete</a>
                                </div>
                            </td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
        </c:when>
        <c:otherwise>
            <div class="no-records">
                <p>No vaccines found. <a href="${pageContext.request.contextPath}/vaccine-master-ui/new">Add a new vaccine</a></p>
            </div>
        </c:otherwise>
    </c:choose>

    <button class="back-btn" onclick="history.back()">Back</button>
</div>

</body>
</html>
