<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EHR System | Patients</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background:#f4f7fb; min-height:100vh; }
        .topbar { background:#0d6efd; }
        .content-card { border:0; border-radius:16px; }
        .patient-code { color:#0d6efd; font-weight:600; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark topbar">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold" href="${pageContext.request.contextPath}/dashboard">EHR System</a>
        <a class="btn btn-outline-light btn-sm" href="${pageContext.request.contextPath}/dashboard">Dashboard</a>
    </div>
</nav>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">
                <c:choose>
                    <c:when test="${module == 'allergies'}">Allergies</c:when>
                    <c:when test="${module == 'history'}">Medical History</c:when>
                    <c:otherwise>Patients</c:otherwise>
                </c:choose>
            </h2>
            <p class="text-muted mb-0">
                <c:choose>
                    <c:when test="${module == 'allergies'}">Select a patient to view allergy records</c:when>
                    <c:when test="${module == 'history'}">Select a patient to view medical history</c:when>
                    <c:otherwise>Search and manage patient records</c:otherwise>
                </c:choose>
            </p>
        </div>

        <c:if test="${pageContext.request.isUserInRole('ADMIN') && module == 'patients'}">
            <a href="${pageContext.request.contextPath}/patients/new" class="btn btn-primary">+ Register Patient</a>
        </c:if>
    </div>

    <c:if test="${not empty successMessage}">
        <div class="alert alert-success">${successMessage}</div>
    </c:if>

    <c:if test="${not empty errorMessage}">
        <div class="alert alert-danger">${errorMessage}</div>
    </c:if>

    <div class="card content-card shadow-sm mb-4">
        <div class="card-body p-4">
            <form action="${pageContext.request.contextPath}/patients" method="get">
                <div class="row g-2">
                    <div class="col-md-9">
                        <input type="text" name="search" value="${search}" class="form-control" placeholder="Search patient by name">
                    </div>
                    <div class="col-md-3 d-grid">
                        <button type="submit" class="btn btn-primary">Search</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card content-card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                    <tr>
                        <th class="ps-4">Patient Code</th>
                        <th>Name</th>
                        <th>Date of Birth</th>
                        <th>Gender</th>
                        <th>Phone</th>
                        <c:if test="${pageContext.request.isUserInRole('ADMIN') || pageContext.request.isUserInRole('DOCTOR') || pageContext.request.isUserInRole('LAB_TECH')}">
                            <th>Actions</th>
                        </c:if>
                    </tr>
                    </thead>
                    <tbody>
                    <c:forEach var="patient" items="${patients}">
                        <tr>
                            <td class="ps-4 patient-code">${patient.patientCode}</td>
                            <td>${patient.name}</td>
                            <td>${patient.dob}</td>
                            <td>${patient.gender}</td>
                            <td>${patient.phone}</td>
                            <c:if test="${pageContext.request.isUserInRole('ADMIN') || pageContext.request.isUserInRole('DOCTOR') || pageContext.request.isUserInRole('LAB_TECH')}">
                                <td>
                                    <c:choose>
                                        <c:when test="${module == 'allergies'}">
                                            <a href="${pageContext.request.contextPath}/patients/${patient.id}/allergies" class="btn btn-sm btn-outline-danger">View Allergies</a>
                                        </c:when>
                                        <c:when test="${module == 'history'}">
                                            <a href="${pageContext.request.contextPath}/patients/${patient.id}/history" class="btn btn-sm btn-outline-success">View History</a>
                                        </c:when>
                                        <c:when test="${pageContext.request.isUserInRole('ADMIN')}">
                                            <a href="${pageContext.request.contextPath}/patients/${patient.id}/edit" class="btn btn-sm btn-outline-secondary ms-1">Edit</a>
                                        </c:when>
                                    </c:choose>
                                </td>
                            </c:if>
                        </tr>
                    </c:forEach>

                    <c:if test="${empty patients}">
                        <tr>
                            <td colspan="${(pageContext.request.isUserInRole('ADMIN') || pageContext.request.isUserInRole('DOCTOR') || pageContext.request.isUserInRole('LAB_TECH')) ? 6 : 5}" class="text-center text-muted py-5">No patients found.</td>
                        </tr>
                    </c:if>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

</body>
</html>
