<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Doctor Notes</title>
    <style>
        body { font-family: Arial, sans-serif; background:#f4f7fb; margin:0; padding:0; }
        .container { max-width: 960px; margin: 30px auto; padding: 0 20px; }
        .card { background:#fff; border-radius:12px; box-shadow:0 2px 10px rgba(0,0,0,.08); padding:20px; }
        .header { display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; }
        .title { font-size: 1.7rem; font-weight: bold; }
        .meta { color:#555; margin:6px 0; }
        .table { width:100%; border-collapse:collapse; margin-top:12px; }
        .table th, .table td { border:1px solid #ddd; padding:10px; text-align:left; }
        .table th { background:#f3f6ff; }
        .back-btn { display:inline-block; margin-top:16px; background:#2c7be5; color:#fff; text-decoration:none; padding:9px 16px; border-radius:6px; }
        .empty { text-align:center; color:#666; padding:18px; }
    </style>
</head>
<body>
<div class="container">
    <div class="card">
        <div class="header">
            <div>
                <div class="title">Doctor Notes</div>
                <div class="meta">Patient: ${patientName} (${patientCode})</div>
            </div>
        </div>

        <table class="table">
            <thead>
            <tr>
                <th>Date</th>
                <th>Type</th>
                <th>Doctor</th>
                <th>Note</th>
            </tr>
            </thead>
            <tbody>
            <c:choose>
                <c:when test="${not empty doctorNotes}">
                    <c:forEach var="note" items="${doctorNotes}">
                        <tr>
                            <td>${note.createdAt}</td>
                            <td>${note.noteType}</td>
                            <td>${note.doctorName}</td>
                            <td>${note.noteText}</td>
                        </tr>
                    </c:forEach>
                </c:when>
                <c:otherwise>
                    <tr>
                        <td colspan="4" class="empty">No doctor notes recorded yet</td>
                    </tr>
                </c:otherwise>
            </c:choose>
            </tbody>
        </table>

        <a href="${pageContext.request.contextPath}/patient-portal?patientId=${patientId}" class="back-btn">Back</a>
    </div>
</div>
</body>
</html>
