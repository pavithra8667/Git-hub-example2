<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Vaccine Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 650px;
            margin: 40px auto;
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 25px;
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #ddd;
        }

        .detail-row:last-child {
            border-bottom: none;
        }

        .detail-label {
            font-weight: bold;
            color: #333;
            width: 40%;
        }

        .detail-value {
            color: #555;
            width: 60%;
        }

        .button-group {
            margin-top: 25px;
            display: flex;
            gap: 10px;
        }

        .btn {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            text-decoration: none;
            text-align: center;
        }

        .btn-edit {
            background: #ffc107;
            color: black;
        }

        .btn-edit:hover {
            background: #e0a800;
        }

        .btn-back {
            background: #6c757d;
            color: white;
        }

        .btn-back:hover {
            background: #5a6268;
        }

        .btn-delete {
            background: #dc3545;
            color: white;
        }

        .btn-delete:hover {
            background: #c82333;
        }

        .active-badge {
            background: #28a745;
            color: white;
            padding: 4px 12px;
            border-radius: 3px;
            font-size: 12px;
        }

        .inactive-badge {
            background: #6c757d;
            color: white;
            padding: 4px 12px;
            border-radius: 3px;
            font-size: 12px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Vaccine Details</h2>

    <div class="detail-row">
        <div class="detail-label">Vaccine Name:</div>
        <div class="detail-value">${vaccine.vaccineName}</div>
    </div>

    <div class="detail-row">
        <div class="detail-label">Max Doses:</div>
        <div class="detail-value">${vaccine.maxDoses}</div>
    </div>

    <div class="detail-row">
        <div class="detail-label">Interval Value:</div>
        <div class="detail-value">${vaccine.intervalValue}</div>
    </div>

    <div class="detail-row">
        <div class="detail-label">Interval Unit:</div>
        <div class="detail-value">${vaccine.intervalUnit}</div>
    </div>

    <div class="detail-row">
        <div class="detail-label">Status:</div>
        <div class="detail-value">
            <c:choose>
                <c:when test="${vaccine.active}">
                    <span class="active-badge">Active</span>
                </c:when>
                <c:otherwise>
                    <span class="inactive-badge">Inactive</span>
                </c:otherwise>
            </c:choose>
        </div>
    </div>

    <div class="button-group">
        <a href="${pageContext.request.contextPath}/vaccine-master-ui/${vaccine.id}/edit" class="btn btn-edit">Edit</a>
        <a href="${pageContext.request.contextPath}/vaccine-master-ui/list" class="btn btn-back">Back to List</a>
        <a href="${pageContext.request.contextPath}/vaccine-master-ui/${vaccine.id}/delete" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this vaccine?')">Delete</a>
    </div>
</div>

</body>
</html>

