<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Vaccine Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
        }

        .container {
            width: min(700px, 90vw);
            margin: 20px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            display: block;
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin: 0 0 12px;
            font-size: 1.6rem;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px 15px;
        }

        .form-group {
            margin: 0;
        }

        .form-group.full-width {
            grid-column: 1 / -1;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 4px;
            color: #333;
            font-size: 14px;
        }

        input,
        select {
            width: 100%;
            padding: 8px 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 14px;
            min-height: 38px;
        }

        input[type="checkbox"] {
            width: auto;
            margin-right: 8px;
            min-height: auto;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            margin: 0;
            grid-column: 1 / -1;
            gap: 6px;
        }

        .checkbox-group label {
            margin: 0;
            font-weight: normal;
            font-size: 14px;
        }

        .form-actions {
            display: flex;
            gap: 10px;
            margin-top: 12px;
            grid-column: 1 / -1;
        }

        .btn {
            width: auto;
            min-width: 0;
            background: #007bff;
            color: white;
            padding: 10px 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            display: inline-block;
            text-align: center;
        }

        .btn:hover {
            background: #0056b3;
        }

        .btn-cancel {
            background: #6c757d;
        }

        .btn-cancel:hover {
            background: #5a6268;
        }

        .error-message {
            color: #dc3545;
            font-weight: bold;
            margin-bottom: 12px;
            padding: 10px;
            background-color: #f8d7da;
            border-radius: 5px;
            font-size: 14px;
        }

        .help-text {
            font-size: 11px;
            color: #666;
            margin-top: 2px;
        }

        @media (max-width: 700px) {
            .form-grid {
                grid-template-columns: 1fr;
            }

            .form-actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h2><c:choose><c:when test="${not empty vaccine.id}">Edit Vaccine</c:when><c:otherwise>Add New Vaccine</c:otherwise></c:choose></h2>

    <c:if test="${not empty errorMessage}">
        <div class="error-message">${errorMessage}</div>
    </c:if>

    <form method="post" action="${pageContext.request.contextPath}/vaccine-master-ui/save">
        <c:if test="${not empty vaccine.id}">
            <input type="hidden" name="id" value="${vaccine.id}">
        </c:if>

        <div class="form-grid">

            <div class="form-group">
                <label for="vaccineName">Vaccine Name <span style="color: red;">*</span></label>
                <input type="text" id="vaccineName" name="vaccineName" value="${vaccine.vaccineName}" required placeholder="e.g., COVID-19, Tetanus">
                <div class="help-text">Enter a unique vaccine name</div>
            </div>

            <div class="form-group">
                <label for="maxDoses">Max Doses <span style="color: red;">*</span></label>
                <input type="number" id="maxDoses" name="maxDoses" value="${vaccine.maxDoses}" min="1" required placeholder="e.g., 2, 3">
                <div class="help-text">Total number of doses required for this vaccine</div>
            </div>

            <div class="form-group">
                <label for="intervalValue">Interval Value <span style="color: red;">*</span></label>
                <input type="number" id="intervalValue" name="intervalValue" value="${vaccine.intervalValue}" min="1" required placeholder="e.g., 21, 28, 365">
                <div class="help-text">Time between doses</div>
            </div>

            <div class="form-group">
                <label for="intervalUnit">Interval Unit <span style="color: red;">*</span></label>
                <select id="intervalUnit" name="intervalUnit" required>
                    <option value="">-- Select Unit --</option>
                    <option value="DAYS" <c:if test="${vaccine.intervalUnit == 'DAYS'}">selected</c:if>>Days</option>
                    <option value="MONTHS" <c:if test="${vaccine.intervalUnit == 'MONTHS'}">selected</c:if>>Months</option>
                    <option value="YEARS" <c:if test="${vaccine.intervalUnit == 'YEARS'}">selected</c:if>>Years</option>
                </select>
                <div class="help-text">Unit for the interval value (e.g., 21 Days, 6 Months, 10 Years)</div>
            </div>

            <div class="checkbox-group" style="grid-column: 1 / -1;">
                <input type="checkbox" id="active" name="active" value="true" <c:if test="${vaccine.active}">checked</c:if>>
                <label for="active">Active</label>
                <div class="help-text" style="margin-left: 0; margin-top: 0;">Check to enable this vaccine for use</div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn">Save Vaccine</button>
                <button type="button" class="btn btn-cancel" onclick="window.location.href='${pageContext.request.contextPath}/vaccine-master-ui/list'">Cancel</button>
            </div>

        </div>

    </form>
</div>

</body>
</html>
