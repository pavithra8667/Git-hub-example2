<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EHR System | Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { margin:0; min-height:100vh; background:#f4f7fb; font-family:Arial,sans-serif; }
        .navbar-custom { background:#0d6efd; }
        .module-card { border:none; border-radius:18px; height:100%; transition:.2s ease; }
        .module-card:hover { transform:translateY(-4px); box-shadow:0 10px 25px rgba(0,0,0,.10); }
        .module-icon { width:55px; height:55px; border-radius:14px; display:flex; align-items:center; justify-content:center; margin-bottom:18px; font-size:24px; font-weight:bold; }
        .patient-icon { background:#e7f1ff; color:#0d6efd; }
        .allergy-icon { background:#fdebec; color:#dc3545; }
        .history-icon { background:#e7f7ed; color:#198754; }
        .visit-icon { background:#fff3d6; color:#b7791f; }
        .vaccine-icon { background:#eefaf6; color:#0f766e; }
        .users-icon { background:#f1e9ff; color:#6f42c1; }
    </style>
</head>
<body>
<nav class="navbar navbar-dark navbar-custom">
    <div class="container-fluid px-4">
        <span class="navbar-brand fw-bold">EHR System</span>
        <div class="d-flex align-items-center gap-3">
            <span class="text-white fw-semibold">${username}</span>
            <span class="badge bg-light text-primary">${role}</span>
            <a href="${pageContext.request.contextPath}/logout" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container py-5">
    <div class="mb-5">
        <h2 class="fw-bold">Dashboard</h2>
        <p class="text-muted">Welcome, ${username}</p>
    </div>

    <div class="row g-4">
        <c:if test="${role == 'ADMIN' || role == 'DOCTOR' || role == 'LAB_TECH'}">
            <div class="col-lg-4 col-md-6">
                <div class="card module-card shadow-sm"><div class="card-body p-4">
                    <div class="module-icon patient-icon">P</div>
                    <h4>Patients</h4>
                    <p class="text-muted">Search and manage patient records.</p>
                    <a href="${pageContext.request.contextPath}/patients?module=patients" class="btn btn-primary">Open Patients</a>
                </div></div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="card module-card shadow-sm"><div class="card-body p-4">
                    <div class="module-icon allergy-icon">!</div>
                    <h4>Allergies</h4>
                    <p class="text-muted">Select a patient to view allergy records.</p>
                    <a href="${pageContext.request.contextPath}/patients?module=allergies" class="btn btn-danger">View Allergies</a>
                </div></div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="card module-card shadow-sm"><div class="card-body p-4">
                    <div class="module-icon history-icon">H</div>
                    <h4>Medical History</h4>
                    <p class="text-muted">Select a patient to view medical history.</p>
                    <a href="${pageContext.request.contextPath}/patients?module=history" class="btn btn-success">View Medical History</a>
                </div></div>
            </div>

            <c:if test="${role == 'ADMIN' || role == 'DOCTOR'}">
                <div class="col-lg-4 col-md-6">
                    <div class="card module-card shadow-sm"><div class="card-body p-4">
                        <div class="module-icon vaccine-icon">VM</div>
                        <h4>Vaccine Master</h4>
                        <p class="text-muted">Manage the vaccine master list (administered vaccines).</p>
                        <a href="${pageContext.request.contextPath}/vaccine-master-ui/list" class="btn btn-info">Open Vaccine Master</a>
                    </div></div>
                </div>
            </c:if>

            <c:if test="${role == 'DOCTOR'}">
                <div class="col-12 mt-2">
                    <div class="border-top pt-4 mt-2">
                        <h4 class="fw-bold mb-3">Visits</h4>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="card module-card shadow-sm"><div class="card-body p-4">
                        <div class="module-icon visit-icon">V</div>
                        <h4>Visits</h4>
                        <p class="text-muted">Open, review, and manage patient visits.</p>
                        <a href="${pageContext.request.contextPath}/visits" class="btn btn-warning text-white">Open Visits</a>
                    </div></div>
                </div>
            </c:if>

            <c:if test="${role == 'LAB_TECH'}">
                <div class="col-12 mt-2">
                    <div class="border-top pt-4 mt-2">
                        <h4 class="fw-bold mb-3">Orders</h4>
                    </div>
                </div>
            </c:if>
        </c:if>

        <c:if test="${role == 'LAB_TECH'}">
            <div class="col-12">
                <div class="card module-card shadow-sm">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h4 class="mb-0">Doctor Orders</h4>
                            <span class="badge bg-primary-subtle text-primary-emphasis">${fn:length(labOrders)}</span>
                        </div>

                        <c:if test="${empty labOrders}">
                            <p class="text-muted mb-0">No lab orders have been created by doctors yet.</p>
                        </c:if>

                        <c:if test="${not empty labOrders}">
                            <div class="table-responsive">
                                <table class="table table-striped align-middle mb-0">
                                    <thead>
                                        <tr>
                                            <th>Test</th>
                                            <th>Status</th>
                                            <th>Visit</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <c:forEach var="order" items="${labOrders}">
                                            <tr>
                                                <td>${order.testName}</td>
                                                <td><span class="badge bg-warning text-dark">${order.status}</span></td>
                                                    <td>${order.patientName}</td>
                                                <td>
                                                        <c:choose>
                                                            <c:when test="${order.status == 'COMPLETED'}">
                                                                <a href="${pageContext.request.contextPath}/lab-results/by-order?labOrderId=${order.id}" class="btn btn-sm btn-outline-secondary">View result</a>
                                                            </c:when>
                                                            <c:when test="${order.status == 'ORDERED'}">
                                                                <a href="${pageContext.request.contextPath}/lab-results/new?labOrderId=${order.id}" class="btn btn-sm btn-outline-primary">Enter result</a>
                                                            </c:when>
                                                            <c:otherwise>
                                                                <button class="btn btn-sm btn-outline-secondary" disabled>${order.status}</button>
                                                            </c:otherwise>
                                                        </c:choose>
                                                    </td>
                                                </tr>
                                        </c:forEach>
                                    </tbody>
                                </table>
                            </div>
                        </c:if>
                    </div>
                </div>
            </div>
        </c:if>

        <c:if test="${role == 'ADMIN'}">
            <div class="col-lg-4 col-md-6">
                <div class="card module-card shadow-sm"><div class="card-body p-4">
                    <div class="module-icon users-icon">U</div>
                    <h4>User Management</h4>
                    <p class="text-muted">Create and view hospital staff login accounts.</p>
                    <a href="${pageContext.request.contextPath}/users" class="btn btn-dark">Manage Users</a>
                </div></div>
            </div>
        </c:if>
    </div>
</div>
</body>
</html>
