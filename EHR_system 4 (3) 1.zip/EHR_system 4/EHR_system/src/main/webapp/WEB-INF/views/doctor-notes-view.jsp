<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>

<!DOCTYPE html>
<html>
<head>
    <title>Doctor Notes History</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    
    <style>
        body{
            background-color:#f4f6f9;
        }

        .card{
            max-width:650px; /* smaller centered card */
            margin:30px auto;
            border-radius:8px;
            box-shadow:0 2px 6px rgba(0,0,0,.12);
            padding:12px !important;
        }

        .card.small {
            max-width:520px;
            padding:10px !important;
        }
    </style>
</head>

<body>

<div class="container">

    <div class="card p-4">

        <h2 class="text-center text-primary mb-4">
            Doctor Notes History
        </h2>

        <div class="mb-2">
            <strong>Patient Name :</strong> ${patientName}
        </div>

        <div class="mb-2">
            <strong>Doctor Name :</strong> ${doctorName}
        </div>

        <div class="mb-3">
            <strong>Visit Status :</strong> 
            <span class="badge ${visitStatus == 'OPEN' ? 'bg-success' : 'bg-danger'}">
                ${visitStatus}
            </span>
        </div>

        <div class="d-flex justify-content-between align-items-center mb-3">
            <a href="javascript:history.back()" class="btn btn-secondary btn-sm text-decoration-none" style="width:auto; padding:6px 12px; min-width: 70px;">Back</a>

            <c:choose>
                <c:when test="${visitStatus == 'CLOSED'}">
                    <button class="btn btn-primary btn-sm" disabled style="padding:6px 12px; min-width: 140px;">
                        Add Doctor Note (Visit Closed)
                    </button>
                </c:when>
                <c:otherwise>
                    <a href="${pageContext.request.contextPath}/doctor-notes/form?visitId=${visitId}&doctorId=${doctorId}"
                       class="btn btn-primary btn-sm" style="padding:6px 12px; min-width: 130px;">
                        Add Doctor Note
                    </a>
                </c:otherwise>
            </c:choose>
        </div>

        <div class="d-flex justify-content-end mb-3">
            <c:url var="vaccinationListUrl" value="/vaccination-ui/list">
                <c:param name="patientId" value="${patientId}" />
                <c:param name="visitId" value="${visitId}" />
                <c:param name="doctorId" value="${doctorId}" />
                <c:param name="doctorName" value="${doctorName}" />
            </c:url>
            <a href="${vaccinationListUrl}" class="btn btn-outline-primary btn-sm text-decoration-none" style="padding:6px 12px; min-width: 140px;">
                Add Vaccination
            </a>
        </div>

        <!-- show success/error message passed via query param (message) -->
        <c:if test="${not empty param.message}">
            <div class="alert alert-success" style="width:100%; display:block;">${fn:escapeXml(param.message)}</div>
        </c:if>

        <c:choose>
            <c:when test="${visitStatus == 'CLOSED'}">
                <div class="alert alert-warning mb-3">
                    ⚠️ This visit is closed. No new doctor notes can be added.
                </div>
            </c:when>
            <c:otherwise>
            </c:otherwise>
        </c:choose>

        <table class="table table-bordered table-hover">

            <thead class="table-primary">
            <tr>
                <th>Date & Time</th>
                <th>Note Type</th>
                <th>Doctor Note</th>
            </tr>
            </thead>

            <tbody>

            <c:choose>

                <c:when test="${not empty doctorNotes}">
                    <c:forEach var="note" items="${doctorNotes}">
                        <tr>
                            <td>${note.createdAt}</td>
                            <td>${note.noteType}</td>
                            <td>${note.noteText}</td>
                        </tr>
                    </c:forEach>
                </c:when>

                <c:otherwise>
                    <tr>
                        <td colspan="3" class="text-center">
                            No doctor notes available
                        </td>
                    </tr>
                </c:otherwise>

            </c:choose>

            </tbody>

        </table>


    </div>

</div>

</body>
</html>