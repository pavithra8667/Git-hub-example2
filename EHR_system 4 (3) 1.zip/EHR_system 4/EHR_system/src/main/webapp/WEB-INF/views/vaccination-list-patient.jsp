<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Vaccination Records</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 900px;
            margin: 40px auto;
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 25px;
        }

        .patient-details {
            margin-bottom: 25px;
        }

        .patient-details p {
            margin: 8px 0;
            font-size: 16px;
        }

        .action-buttons {
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #007bff;
            color: white;
            padding: 12px;
            border: 1px solid #ddd;
        }

        td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }

        tr:nth-child(even) {
            background: #f8f9fa;
        }

        .back-btn {
            margin-top: 25px;
            background: #28a745;
            color: white;
            padding: 10px 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 15px;
        }

        .back-btn:hover {
            background: #218838;
        }

        .add-btn {
            background: #28a745;
            color: white;
            padding: 10px 18px;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            font-weight: bold;
        }

        .add-btn:hover {
            background: #218838;
        }

        .no-records {
            padding: 20px;
            text-align: center;
            color: #666;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Vaccination History</h2>

    <div class="patient-details">
        <p><strong>Patient ID :</strong> ${patientCode}</p>
        <p><strong>Patient Name :</strong> ${patientName}</p>
        <p><strong>Age :</strong> ${age}</p>
        <p><strong>Gender :</strong> ${gender}</p>
    </div>

    <c:choose>
        <c:when test="${not empty vaccinations}">
            <table>
                <tr>
                    <th>Vaccine Name</th>
                    <th>Dose</th>
                    <th>Administered Date</th>
                    <th>Administered By</th>
                    <th>Next Due Date</th>
                </tr>

                <c:forEach var="vaccine" items="${vaccinations}">
                    <tr>
                        <td>${vaccine.vaccineName}</td>
                        <td>${vaccine.doseNumber}</td>
                        <td>${vaccine.administeredDate}</td>
                        <td>${vaccine.administeredBy}</td>
                        <td>
                            <c:choose>
                                <c:when test="${not empty vaccine.nextDueDate}">
                                    ${vaccine.nextDueDate}
                                </c:when>
                                <c:otherwise>
                                    -
                                </c:otherwise>
                            </c:choose>
                        </td>
                    </tr>
                </c:forEach>
            </table>
        </c:when>
        <c:otherwise>
            <div class="no-records">
                <p>No vaccination records found for this patient.</p>
            </div>
        </c:otherwise>
    </c:choose>

    <button class="back-btn" onclick="history.back()">Back</button>
</div>

</body>
</html>

