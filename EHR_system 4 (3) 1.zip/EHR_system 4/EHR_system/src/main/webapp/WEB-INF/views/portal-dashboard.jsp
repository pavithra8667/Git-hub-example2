<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Patient Portal</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f4f7fb; }
        .container { max-width: 1100px; margin: 0 auto; padding: 18px 14px 30px; }
        .header { background: linear-gradient(135deg, #5e61d9 0%, #7b46b8 100%); color: white; padding: 18px 22px; border-radius: 10px; margin-bottom: 18px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .header h1 { font-size: 24px; margin: 0 0 6px; }
        .header p { font-size: 13px; opacity: 0.95; margin: 0; }
        .patient-box { background:white; padding:18px 20px; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,0.08); margin-bottom:20px; display:grid; grid-template-columns:repeat(4, minmax(150px, 1fr)); gap:12px 18px; }
        .patient-box div { padding:6px 0; }
        .patient-box strong { display:block; font-size:12px; color:#555; margin-bottom:4px; }
        .patient-box span { font-size:14px; }
        .section-btn { display:flex; align-items:center; gap:10px; width:100%; background:#fff; border:1px solid #dbe3f0; border-radius:10px; font-size:15px; font-weight:600; color:#1f2d3d; text-decoration:none; padding:14px 16px; margin-bottom:12px; box-shadow:0 1px 4px rgba(0,0,0,0.04); transition:all 0.2s ease; }
        .section-btn:hover { transform: translateY(-1px); box-shadow:0 4px 10px rgba(0,0,0,0.08); border-color:#9ec4ff; }
        .section-badge { display:inline-flex; align-items:center; justify-content:center; width:24px; height:24px; border-radius:6px; background:#eaf2ff; color:#2d6cdf; font-size:14px; }
        .subtext { color:#6b7280; font-size:12px; margin-left:auto; }
        .button-group { text-align:center; margin: 18px 0 8px; }
        .btn { display:inline-block; background:#2d6cdf; color:white; padding:9px 18px; border-radius:6px; text-decoration:none; margin:0 6px; font-size:14px; }
        .btn:hover { background:#2257bc; }
        .logout { background:#dc3545; }
        .logout:hover { background:#bb2d3b; }
        @media (max-width: 768px) {
            .patient-box { grid-template-columns: 1fr 1fr; }
        }
        @media (max-width: 520px) {
            .patient-box { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>📋 Patient Portal - Medical Records</h1>
        <p>View your complete medical history, test results, prescriptions, and vaccination records</p>
    </div>

    <c:choose>
        <c:when test="${not empty portal and not empty portal.patient}">
            <!-- Patient Information Section -->
            <div class="patient-box">
                <div>
                    <strong>Patient ID:</strong><br/>
                    <span>${portal.patient.patientCode}</span>
                </div>
                <div>
                    <strong>Name:</strong><br/>
                    <span>${portal.patient.name}</span>
                </div>
                <div>
                    <strong>Age:</strong><br/>
                    <span>${age} years</span>
                </div>
                <div>
                    <strong>Gender:</strong><br/>
                    <span>${portal.patient.gender}</span>
                </div>
                <div>
                    <strong>Phone:</strong><br/>
                    <span>${not empty portal.patient.phone ? portal.patient.phone : 'N/A'}</span>
                </div>
                <div>
                    <strong>Blood Group:</strong><br/>
                    <span>${not empty portal.patient.bloodGroup ? portal.patient.bloodGroup : 'Not Specified'}</span>
                </div>
                <c:if test="${not empty portal.patient.guardianName}">
                    <div>
                        <strong>Guardian:</strong><br/>
                        <span>${portal.patient.guardianName}</span>
                    </div>
                </c:if>
            </div>

            <a class="section-btn" href="${pageContext.request.contextPath}/patients/${portal.patient.id}/history">
                <span class="section-badge">📚</span>
                <span>Medical History</span>
                <span class="subtext"><c:choose><c:when test="${empty portal.medicalHistories}">0 records</c:when><c:otherwise>${portal.medicalHistories.size()} records</c:otherwise></c:choose></span>
            </a>

            <a class="section-btn" href="${pageContext.request.contextPath}/patients/${portal.patient.id}/allergies">
                <span class="section-badge">⚠️</span>
                <span>Allergies</span>
                <span class="subtext"><c:choose><c:when test="${empty portal.allergies}">0 records</c:when><c:otherwise>${portal.allergies.size()} records</c:otherwise></c:choose></span>
            </a>

            <a class="section-btn" href="${pageContext.request.contextPath}/patients/${portal.patient.id}">
                <span class="section-badge">🩺</span>
                <span>Diagnoses</span>
                <span class="subtext"><c:choose><c:when test="${empty portal.diagnoses}">0 records</c:when><c:otherwise>${portal.diagnoses.size()} records</c:otherwise></c:choose></span>
            </a>

            <a class="section-btn" href="${pageContext.request.contextPath}/patients/${portal.patient.id}">
                <span class="section-badge">🔬</span>
                <span>Lab Results</span>
                <span class="subtext"><c:choose><c:when test="${empty portal.labResults}">0 records</c:when><c:otherwise>${portal.labResults.size()} records</c:otherwise></c:choose></span>
            </a>

            <a class="section-btn" href="${pageContext.request.contextPath}/patients/${portal.patient.id}">
                <span class="section-badge">💊</span>
                <span>Prescriptions</span>
                <span class="subtext"><c:choose><c:when test="${empty portal.prescriptions}">0 records</c:when><c:otherwise>${portal.prescriptions.size()} records</c:otherwise></c:choose></span>
            </a>

            <a class="section-btn" href="${pageContext.request.contextPath}/vaccination-ui/list/patient?patientId=${portal.patient.id}">
                <span class="section-badge">💉</span>
                <span>Vaccinations</span>
                <span class="subtext"><c:choose><c:when test="${empty portal.vaccinations}">0 records</c:when><c:otherwise>${portal.vaccinations.size()} records</c:otherwise></c:choose></span>
            </a>

            <a class="section-btn" href="${pageContext.request.contextPath}/patient-doctor-notes?patientId=${portal.patient.id}">
                <span class="section-badge">📝</span>
                <span>Doctor Notes</span>
                <span class="subtext"><c:choose><c:when test="${empty portal.doctorNotes}">0 records</c:when><c:otherwise>${portal.doctorNotes.size()} records</c:otherwise></c:choose></span>
            </a>

            <div class="button-group">
                <a class="btn" href="${pageContext.request.contextPath}/patient-portal?patientId=${portal.patient.id}">Refresh</a>
                <a class="btn" href="javascript:window.print()">Print Records</a>
                <a class="btn logout" href="${pageContext.request.contextPath}/logout">Logout</a>
            </div>

        </c:when>
        <c:otherwise>
            <div class="section">
                <p style="text-align: center; color: #999;">No patient information available. Please contact the reception desk to register or provide a valid Patient ID.</p>
            </div>
        </c:otherwise>
    </c:choose>

</div>
</body>
</html>

