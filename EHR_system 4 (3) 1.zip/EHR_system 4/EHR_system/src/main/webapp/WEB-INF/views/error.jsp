<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Error</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .container { max-width: 800px; margin: auto; }
        h1 { color: #c0392b; }
        pre { background:#f4f4f4; padding:10px; }
    </style>
</head>
<body>
<div class="container">
    <h1>Something went wrong</h1>
    <p>The application encountered an error. Please contact the administrator.</p>
    <h3>Details (for developers)</h3>
    <pre>
        Status: ${status}
        Error: ${error}
        Message: ${message}
        Path: ${path}
    </pre>
    <p><a href="/">Return to home</a></p>
</div>
</body>
</html>

