<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html>
<head>
    <title>Record Vaccination</title>

    <style>
        body{
            font-family: Arial, sans-serif;
            background:#f4f6f9;
            margin:0;
            padding:0;
            display:flex;
            justify-content:center;
        }

        .container{
            width:min(700px, 90vw);
            margin:20px auto;
            background:white;
            padding:18px 20px;
            border-radius:8px;
            box-shadow:0 2px 8px rgba(0,0,0,0.15);
            display:block;
        }

        h2{
            text-align:center;
            color:#2c3e50;
            margin:0 0 15px;
            font-size:1.8rem;
        }

        .form-grid{
            display:grid;
            grid-template-columns:repeat(2, 1fr);
            gap:12px 15px;
        }

        .form-group{
            margin:0;
        }

        label{
            display:block;
            font-weight:bold;
            margin-bottom:4px;
            color:#333;
            font-size:14px;
        }

        input,
        select{
            width:100%;
            padding:8px 10px;
            border:1px solid #ccc;
            border-radius:5px;
            box-sizing:border-box;
            font-size:14px;
            height:38px;
        }

        input[readonly]{
            background:#f0f0f0;
            cursor:not-allowed;
        }

        .form-actions{
            display:flex;
            gap:10px;
            margin-top:15px;
        }

        .btn{
            background:#007bff;
            color:white;
            padding:10px 18px;
            border:none;
            border-radius:5px;
            cursor:pointer;
            font-size:14px;
            font-weight:bold;
            text-decoration:none;
        }

        .btn:hover{
            background:#0056b3;
        }

        .btn-dashboard{
            background:#28a745;
        }

        .btn-dashboard:hover{
            background:#218838;
        }

        .error-message{
            color:#dc3545;
            font-weight:bold;
            margin-bottom:12px;
            padding:10px;
            background:#f8d7da;
            border-radius:5px;
        }

        @media (max-width:700px){
            .form-grid{
                grid-template-columns:1fr;
            }

            .form-actions{
                flex-direction:column;
            }
        }
    </style>

</head>

<body>

<div class="container">

    <h2>Record Vaccination</h2>

    <c:if test="${not empty errorMessage}">
        <div class="error-message">
            ${errorMessage}
        </div>
    </c:if>

    <form method="post" action="${pageContext.request.contextPath}/vaccination-ui/save">
        <input type="hidden"
               name="patientId"
               value="${patientId}">
        <input type="hidden"
               name="visitId"
               value="${visitId}">
        <input type="hidden"
               name="doctorId"
               value="${doctorId}">

        <div class="form-grid">

            <div class="form-group">
                <label>Patient ID</label>
                <input type="text"
                       name="patientCode"
                       value="${patientCode}"
                       readonly>
            </div>

            <div class="form-group">
                <label>Patient Name</label>
                <input type="text"
                       name="patientName"
                       value="${patientName}"
                       readonly>
            </div>

            <div class="form-group">
                <label>Vaccine Name</label>

                <select id="vaccineName"
                        name="vaccineName"
                        required>

                    <option value="">Select Vaccine</option>

                    <c:forEach var="v" items="${vaccines}">
                        <option value="${v.vaccineName}">
                            ${v.vaccineName}
                        </option>
                    </c:forEach>

                </select>
            </div>

            <div class="form-group">
                <label>Dose Number</label>

                <input type="number"
                       id="doseNumber"
                       name="doseNumber"
                       min="1"
                       readonly>
            </div>

            <div class="form-group">
                <label>Administered Date</label>

                <input type="date"
                       id="administeredDate"
                       name="administeredDate"
                       required
                       value="${administeredDateDefault}">
            </div>

            <div class="form-group">
                <label>Administered By</label>

                <input type="text"
                       name="administeredBy"
                       value="${administeredBy}"
                       readonly>
            </div>

            <div class="form-group">
                <label>Next Due Date</label>

                <input type="date"
                       id="nextDueDate"
                       name="nextDueDate"
                       readonly>
            </div>

        </div>

        <script>
            (function(){

                const vaccineEl = document.getElementById('vaccineName');
                const dateEl = document.getElementById('administeredDate');
                const doseEl = document.getElementById('doseNumber');
                const nextDueEl = document.getElementById('nextDueDate');

                function compute(){

                    const vaccine = vaccineEl.value;

                    if(!vaccine){
                        doseEl.value = '';
                        nextDueEl.value = '';
                        return;
                    }

                    const patientId =
                        document.querySelector(
                            'input[name="patientId"]'
                        ).value;

                    const administeredDate =
                        dateEl.value;

                    const params =
                        new URLSearchParams();

                    if(patientId){
                        params.append(
                            'patientId',
                            patientId
                        );
                    }

                    params.append(
                        'vaccineName',
                        vaccine
                    );

                    if(administeredDate){
                        params.append(
                            'administeredDate',
                            administeredDate
                        );
                    }

                    fetch(
                        window.location.origin +
                        '${pageContext.request.contextPath}/vaccination-ui/compute?' +
                        params.toString()
                    )
                    .then(r => r.json())
                    .then(data => {

                        if(data.nextDoseNumber !== undefined){
                            doseEl.value =
                                data.nextDoseNumber;
                        }

                        if(data.nextDueDate){
                            nextDueEl.value =
                                data.nextDueDate;
                        }else{
                            nextDueEl.value = '';
                        }

                    })
                    .catch(err => {
                        console.error(
                            'compute error',
                            err
                        );
                    });
                }

                vaccineEl.addEventListener(
                    'change',
                    compute
                );

                dateEl.addEventListener(
                    'change',
                    compute
                );

                document.addEventListener(
                    'DOMContentLoaded',
                    function(){
                        setTimeout(
                            compute,
                            50
                        );
                    }
                );

            })();
        </script>

        <div class="form-actions">

            <button type="submit"
                    class="btn">
                Save Vaccination
            </button>



        </div>

    </form>

</div>

</body>
</html>