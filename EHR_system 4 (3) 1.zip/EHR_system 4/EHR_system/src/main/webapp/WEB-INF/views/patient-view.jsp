<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EHR System | Patient Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background:#f4f7fb; min-height:100vh; }
        .topbar { background:#0d6efd; }
        .details-card { border:0; border-radius:16px; }
        .label { color:#6c757d; font-size:.9rem; }
        .value { font-weight:600; }
    </style>
</head>
<body>
<nav class="navbar navbar-dark topbar">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold" href="${pageContext.request.contextPath}/dashboard">EHR System</a>
        <a class="btn btn-outline-light btn-sm" href="${pageContext.request.contextPath}/patients">Patients</a>
    </div>
</nav>

<div class="container py-5">
    <div class="card details-card shadow-sm">
        <div class="card-body p-4 p-md-5">
            <div class="d-flex justify-content-between align-items-start mb-4">
                <div>
                    <h2 class="fw-bold mb-2">Patient Details</h2>
                    <span class="badge bg-primary">${patient.patientCode}</span>
                </div>

                <c:if test="${pageContext.request.isUserInRole('ADMIN')}">
                    <a href="${pageContext.request.contextPath}/patients/${patient.id}/edit" class="btn btn-outline-primary">Edit Patient</a>
                </c:if>
            </div>

            <c:if test="${not empty successMessage}">
                <div class="alert alert-success">${successMessage}</div>
            </c:if>

            <div class="row g-4">
                <div class="col-md-6">
                    <div class="label">Name</div>
                    <div class="value">${patient.name}</div>
                </div>
                <div class="col-md-6">
                    <div class="label">Date of Birth</div>
                    <div class="value">${patient.dob}</div>
                </div>
                <div class="col-md-6">
                    <div class="label">Gender</div>
                    <div class="value">${patient.gender}</div>
                </div>
                <div class="col-md-6">
                    <div class="label">Phone</div>
                    <div class="value">${patient.phone}</div>
                </div>
                <div class="col-md-6">
                    <div class="label">Guardian Name</div>
                    <div class="value">
                        <c:choose>
                            <c:when test="${not empty patient.guardianName}">${patient.guardianName}</c:when>
                            <c:otherwise>Not Applicable</c:otherwise>
                        </c:choose>
                    </div>
                </div>
            </div>

            <hr class="my-4">

            <div class="d-flex flex-wrap gap-2">
                <a href="${pageContext.request.contextPath}/patients" class="btn btn-outline-secondary">Back to Patients</a>
                <a href="${pageContext.request.contextPath}/patients/${patient.id}/allergies" class="btn btn-outline-danger">Allergies</a>
                <a href="${pageContext.request.contextPath}/patients/${patient.id}/history" class="btn btn-outline-success">Medical History</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>
