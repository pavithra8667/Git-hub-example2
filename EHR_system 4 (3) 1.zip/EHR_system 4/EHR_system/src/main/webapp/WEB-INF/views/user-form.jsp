<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EHR System | Add User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>.field-error{color:#dc3545;font-size:.875rem;display:block;margin-top:.25rem}</style>
</head>
<body class="bg-light">
<nav class="navbar navbar-dark bg-primary">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold" href="${pageContext.request.contextPath}/dashboard">EHR System</a>
        <a class="btn btn-outline-light btn-sm" href="${pageContext.request.contextPath}/users">Users</a>
    </div>
</nav>
<div class="container py-5">
    <div class="card border-0 shadow-sm mx-auto" style="max-width:720px">
        <div class="card-body p-4 p-md-5">
            <h2 class="fw-bold mb-4">Add User</h2>

            <c:if test="${not empty errorMessage}">
                <div class="alert alert-danger">${errorMessage}</div>
            </c:if>

            <form:form method="post" action="${pageContext.request.contextPath}/users" modelAttribute="userForm">
                <div class="mb-3">
                    <label for="username" class="form-label fw-semibold">Username</label>
                    <form:input path="username" id="username" cssClass="form-control" />
                    <form:errors path="username" cssClass="field-error" />
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label fw-semibold">Email</label>
                    <form:input path="email" id="email" type="email" cssClass="form-control" />
                    <form:errors path="email" cssClass="field-error" />
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label fw-semibold">Initial Password</label>
                    <form:password path="password" id="password" cssClass="form-control" />
                    <form:errors path="password" cssClass="field-error" />
                </div>
                <div class="mb-4">
                    <label for="roleName" class="form-label fw-semibold">Role</label>
                    <form:select path="roleName" id="roleName" cssClass="form-select">
                        <form:option value="" label="Select role" />
                        <c:forEach var="role" items="${roles}">
                            <form:option value="${role}" label="${role}" />
                        </c:forEach>
                    </form:select>
                    <form:errors path="roleName" cssClass="field-error" />
                </div>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">Create User</button>
                    <a href="${pageContext.request.contextPath}/users" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </form:form>
        </div>
    </div>
</div>
</body>
</html>
