<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EHR System | Change Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { margin:0; min-height:100vh; background:#f4f7fb; font-family:Arial,sans-serif; }
        .login-wrapper { min-height:100vh; display:flex; justify-content:center; align-items:center; }
        .login-card { width:100%; max-width:420px; border:0; border-radius:18px; box-shadow:0 8px 30px rgba(0,0,0,.10); }
        .ehr-logo { width:65px; height:65px; margin:0 auto 18px; border-radius:50%; background:#198754; color:#fff; display:flex; align-items:center; justify-content:center; font-size:34px; font-weight:700; }
        .ehr-title { color:#198754; font-weight:700; }
        .form-label { font-weight:600; }
        .form-control { min-height:48px; border-radius:9px; }
        .login-button { min-height:48px; border-radius:9px; font-weight:600; }
    </style>
</head>
<body>
<div class="container">
    <div class="login-wrapper">
        <div class="card login-card">
            <div class="card-body p-5">
                <div class="ehr-logo">P</div>
                <div class="text-center mb-4">
                    <h2 class="ehr-title">Change Password</h2>
                    <p class="text-muted mb-0">Your default password must be updated before portal access.</p>
                </div>

                <c:if test="${not empty errorMessage}">
                    <div class="alert alert-danger text-center">${errorMessage}</div>
                </c:if>

                <form action="${pageContext.request.contextPath}/patient/change-password" method="post">
                    <input type="hidden" name="username" value="${username}" />

                    <div class="mb-3">
                        <label for="currentPassword" class="form-label">Current Password</label>
                        <input type="password" id="currentPassword" name="currentPassword" class="form-control" placeholder="Enter current password" required>
                    </div>

                    <div class="mb-3">
                        <label for="newPassword" class="form-label">New Password</label>
                        <input type="password" id="newPassword" name="newPassword" class="form-control" placeholder="Enter new password" required>
                    </div>

                    <div class="mb-4">
                        <label for="confirmPassword" class="form-label">Confirm New Password</label>
                        <input type="password" id="confirmPassword" name="confirmPassword" class="form-control" placeholder="Confirm new password" required>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-success login-button">Update Password</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>
