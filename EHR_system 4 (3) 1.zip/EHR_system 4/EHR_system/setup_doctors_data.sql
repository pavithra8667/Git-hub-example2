-- SQL Script to Create Doctors Table and Insert Test Data

-- 1. CREATE DOCTORS TABLE
CREATE TABLE IF NOT EXISTS doctors (
    id VARCHAR(36) NOT NULL PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL UNIQUE,
    specialization VARCHAR(100) NOT NULL,
    qualification VARCHAR(150) NOT NULL,
    license_number VARCHAR(50) NOT NULL UNIQUE,
    years_of_experience INT NOT NULL,
    phone VARCHAR(20) NOT NULL UNIQUE,
    address VARCHAR(255),
    clinic_name VARCHAR(150),
    is_available BOOLEAN NOT NULL DEFAULT TRUE,
    consultation_fee DECIMAL(10, 2) NOT NULL,
    created_by VARCHAR(255),
    created_on DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by VARCHAR(255),
    updated_on DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- 2. INSERT ROLES (if not already present)
INSERT IGNORE INTO roles (id, name) VALUES 
  ('550e8400-e29b-41d4-a716-446655440001', 'ADMIN'),
  ('550e8400-e29b-41d4-a716-446655440002', 'Doctor'),
  ('550e8400-e29b-41d4-a716-446655440003', 'LAB_TECH');

-- 3. INSERT DOCTORS USERS
INSERT IGNORE INTO users (id, username, email, password, role_id, status, failed_attempts) 
VALUES 
  ('22222222-2222-2222-2222-222222222222', 'dr_smith', 'smith@hospital.com', 
   '$2b$10$UcYlX1EEdSPnktNsTyjnUOBCwVpb1db6B4zczun8R1LhGDlTtk.ge', '550e8400-e29b-41d4-a716-446655440002', 'ACTIVE', 0),
  
  ('33333333-3333-3333-3333-333333333333', 'dr_patel', 'patel@hospital.com',
   '$2b$10$UcYlX1EEdSPnktNsTyjnUOBCwVpb1db6B4zczun8R1LhGDlTtk.ge', '550e8400-e29b-41d4-a716-446655440002', 'ACTIVE', 0),
  
  ('44444444-4444-4444-4444-444444444444', 'dr_johnson', 'johnson@hospital.com',
   '$2b$10$UcYlX1EEdSPnktNsTyjnUOBCwVpb1db6B4zczun8R1LhGDlTtk.ge', '550e8400-e29b-41d4-a716-446655440002', 'ACTIVE', 0);

-- 4. INSERT ADMIN USER
INSERT IGNORE INTO users (id, username, email, password, role_id, status, failed_attempts) 
VALUES 
  ('11111111-1111-1111-1111-111111111111', 'admin', 'admin@hospital.com',
   '$2b$10$UcYlX1EEdSPnktNsTyjnUOBCwVpb1db6B4zczun8R1LhGDlTtk.ge', '550e8400-e29b-41d4-a716-446655440001', 'ACTIVE', 0);

-- 5. INSERT DOCTOR DETAILS
INSERT IGNORE INTO doctors (id, user_id, specialization, qualification, license_number, 
                            years_of_experience, phone, address, clinic_name, 
                            is_available, consultation_fee) 
VALUES 
  ('77777777-7777-7777-7777-777777777777', '22222222-2222-2222-2222-222222222222', 
   'Cardiology', 'MD, DM Cardiology', 'LIC-001', 15, 
   '9876543210', '123 Main Street, City Hospital', 'City Cardiology Clinic', true, 1000.00),
  
  ('88888888-8888-8888-8888-888888888888', '33333333-3333-3333-3333-333333333333', 
   'Orthopedics', 'MBBS, MS Orthopedics', 'LIC-002', 10, 
   '9876543211', '456 Health Road, Medical Complex', 'Bone Care Clinic', true, 800.00),
  
  ('99999999-9999-9999-9999-999999999999', '44444444-4444-4444-4444-444444444444', 
   'General Practice', 'MBBS, MD General Medicine', 'LIC-003', 8, 
   '9876543212', '789 Wellness Avenue, Wellness Center', 'Family Health Clinic', true, 500.00);

-- 6. INSERT PATIENTS (if not already present)
INSERT IGNORE INTO patients (id, patient_code, name, dob, gender, phone, blood_group) 
VALUES 
  ('7a54da5f-704f-4764-829f-70e6a0fd4fcf', 'P001', 'John Doe', '1990-05-15', 'M', '9876543213', 'O+'),
  ('550e8400-e29b-41d4-a716-446655440000', 'P002', 'Jane Smith', '1985-08-20', 'F', '9876543214', 'B+'),
  ('660e8400-e29b-41d4-a716-446655440000', 'P003', 'Robert Wilson', '1988-12-10', 'M', '9876543215', 'AB+');

-- 7. VERIFY DATA
SELECT u.id, u.username, d.specialization, d.license_number, d.years_of_experience 
FROM users u 
JOIN doctors d ON u.id = d.user_id 
JOIN roles r ON u.role_id = r.id 
WHERE r.name = 'Doctor';

SELECT id, patient_code, name, phone FROM patients;
